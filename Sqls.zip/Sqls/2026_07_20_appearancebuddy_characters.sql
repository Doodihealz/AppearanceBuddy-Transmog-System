-- AppearanceBuddy characters schema migration.
-- Run this while worldserver is stopped, with acore_characters selected.

DROP PROCEDURE IF EXISTS appearancebuddy_characters_migrate_20260720;
DELIMITER $$
CREATE PROCEDURE appearancebuddy_characters_migrate_20260720()
BEGIN
    DECLARE current_database_name VARCHAR(64);
    DECLARE state_exists INT DEFAULT 0;
    DECLARE enchant_exists INT DEFAULT 0;
    DECLARE state_required_columns INT DEFAULT 0;
    DECLARE enchant_required_columns INT DEFAULT 0;
    DECLARE state_primary_pair INT DEFAULT 0;
    DECLARE state_unique_pair INT DEFAULT 0;
    DECLARE state_index_count INT DEFAULT 0;
    DECLARE state_canonical_columns INT DEFAULT 0;
    DECLARE state_newest_id_selector INT DEFAULT 1;
    DECLARE enchant_newest_id_selector INT DEFAULT 1;
    DECLARE state_unique_pair INT DEFAULT 0;
    DECLARE enchant_unique_pair INT DEFAULT 0;

    SELECT DATABASE() INTO current_database_name;
    IF current_database_name IS NULL
       OR NOT EXISTS (SELECT 1 FROM information_schema.tables
                      WHERE table_schema = current_database_name AND table_name = 'characters') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'AppearanceBuddy character migration must be run against acore_characters.';
    END IF;

    SELECT COUNT(*) INTO state_exists FROM information_schema.tables
      WHERE table_schema = current_database_name AND table_name = 'character_transmog';
    SELECT COUNT(*) INTO enchant_exists FROM information_schema.tables
      WHERE table_schema = current_database_name AND table_name = 'character_transmog_weapon_enchant';
    IF state_exists = 1 THEN
        SELECT COUNT(*) INTO state_required_columns FROM information_schema.columns
          WHERE table_schema = current_database_name AND table_name = 'character_transmog'
            AND column_name IN ('player_guid', 'slot', 'item', 'real_item');
    END IF;
    IF enchant_exists = 1 THEN
        SELECT COUNT(*) INTO enchant_required_columns FROM information_schema.columns
          WHERE table_schema = current_database_name AND table_name = 'character_transmog_weapon_enchant'
            AND column_name IN ('player_guid', 'equipment_slot', 'enchant_id');
    END IF;
    IF state_exists = 1 AND state_required_columns <> 4 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'character_transmog has an incompatible schema; migration stopped without changes.';
    END IF;
    IF enchant_exists = 1 AND enchant_required_columns <> 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'character_transmog_weapon_enchant has an incompatible schema; migration stopped without changes.';
    END IF;

    CREATE TABLE IF NOT EXISTS character_transmog_migrating_20260720 (
        player_guid INT UNSIGNED NOT NULL,
        slot SMALLINT UNSIGNED NOT NULL,
        item INT UNSIGNED NULL,
        real_item INT UNSIGNED NULL,
        PRIMARY KEY (player_guid, slot)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    CREATE TABLE IF NOT EXISTS character_transmog_weapon_enchant_migrating_20260720 (
        player_guid INT UNSIGNED NOT NULL,
        equipment_slot TINYINT UNSIGNED NOT NULL,
        enchant_id SMALLINT UNSIGNED NOT NULL,
        PRIMARY KEY (player_guid, equipment_slot)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

    IF state_exists = 1 THEN
        INSERT INTO character_transmog_migrating_20260720 (player_guid, slot, item, real_item)
        SELECT player_guid, slot, item, real_item FROM character_transmog
        ON DUPLICATE KEY UPDATE item = VALUES(item), real_item = VALUES(real_item);
    END IF;
    IF enchant_exists = 1 THEN
        INSERT INTO character_transmog_weapon_enchant_migrating_20260720 (player_guid, equipment_slot, enchant_id)
        SELECT player_guid, equipment_slot, enchant_id FROM character_transmog_weapon_enchant
        ON DUPLICATE KEY UPDATE enchant_id = VALUES(enchant_id);
    END IF;

    SELECT COUNT(*) INTO state_unique_pair FROM (
        SELECT index_name FROM information_schema.statistics
         WHERE table_schema = current_database_name AND table_name = 'character_transmog' AND non_unique = 0
         GROUP BY index_name
        HAVING GROUP_CONCAT(column_name ORDER BY seq_in_index) = 'player_guid,slot'
    ) AS state_keys;
    SELECT COUNT(*) INTO enchant_unique_pair FROM (
        SELECT index_name FROM information_schema.statistics
         WHERE table_schema = current_database_name AND table_name = 'character_transmog_weapon_enchant' AND non_unique = 0
         GROUP BY index_name
        HAVING GROUP_CONCAT(column_name ORDER BY seq_in_index) = 'player_guid,equipment_slot'
    ) AS enchant_keys;

    IF state_exists = 1 AND state_unique_pair = 0 THEN
        IF EXISTS (SELECT 1 FROM information_schema.tables
                   WHERE table_schema = current_database_name AND table_name = 'character_transmog_backup_20260720') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'character_transmog_backup_20260720 already exists; inspect it before retrying.';
        END IF;
        RENAME TABLE character_transmog TO character_transmog_backup_20260720,
                     character_transmog_migrating_20260720 TO character_transmog;
    ELSEIF state_exists = 0 THEN
        RENAME TABLE character_transmog_migrating_20260720 TO character_transmog;
    ELSE
        DROP TABLE character_transmog_migrating_20260720;
    END IF;
    IF enchant_exists = 1 AND enchant_unique_pair = 0 THEN
        IF EXISTS (SELECT 1 FROM information_schema.tables
                   WHERE table_schema = current_database_name AND table_name = 'character_transmog_weapon_enchant_backup_20260720') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'character_transmog_weapon_enchant_backup_20260720 already exists; inspect it before retrying.';
        END IF;
        RENAME TABLE character_transmog_weapon_enchant TO character_transmog_weapon_enchant_backup_20260720,
                     character_transmog_weapon_enchant_migrating_20260720 TO character_transmog_weapon_enchant;
    ELSEIF enchant_exists = 0 THEN
        RENAME TABLE character_transmog_weapon_enchant_migrating_20260720 TO character_transmog_weapon_enchant;
    ELSE
        DROP TABLE character_transmog_weapon_enchant_migrating_20260720;
    END IF;
END$$
DELIMITER ;

CALL appearancebuddy_characters_migrate_20260720();
DROP PROCEDURE IF EXISTS appearancebuddy_characters_migrate_20260720;
