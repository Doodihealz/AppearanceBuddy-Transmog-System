-- AppearanceBuddy auth schema migration.
-- Run this while worldserver is stopped, with acore_auth selected.
-- The procedure validates the target database before making schema changes.

DROP PROCEDURE IF EXISTS appearancebuddy_auth_migrate_20260720;
DELIMITER $$
CREATE PROCEDURE appearancebuddy_auth_migrate_20260720()
BEGIN
    DECLARE current_database_name VARCHAR(64);
    DECLARE collection_exists INT DEFAULT 0;
    DECLARE tombstone_exists INT DEFAULT 0;
    DECLARE collection_column_count INT DEFAULT 0;
    DECLARE tombstone_column_count INT DEFAULT 0;
    DECLARE exact_collection_keys INT DEFAULT 0;
    DECLARE exact_tombstone_keys INT DEFAULT 0;

    SELECT DATABASE() INTO current_database_name;
    IF current_database_name IS NULL
       OR NOT EXISTS (SELECT 1 FROM information_schema.tables
                      WHERE table_schema = current_database_name AND table_name = 'account') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'AppearanceBuddy auth migration must be run against acore_auth.';
    END IF;

    SELECT COUNT(*) INTO collection_exists
      FROM information_schema.tables
     WHERE table_schema = current_database_name AND table_name = 'account_transmog';
    SELECT COUNT(*) INTO tombstone_exists
      FROM information_schema.tables
     WHERE table_schema = current_database_name AND table_name = 'account_transmog_removed_appearance';

    IF collection_exists = 1 THEN
        SELECT COUNT(*) INTO collection_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name AND table_name = 'account_transmog'
           AND column_name IN ('account_id', 'unlocked_item_id', 'display_id', 'inventory_type', 'item_name');
    END IF;
    IF tombstone_exists = 1 THEN
        SELECT COUNT(*) INTO tombstone_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name AND table_name = 'account_transmog_removed_appearance'
           AND column_name IN ('account_id', 'display_id');
    END IF;

    -- Do not overwrite unknown legacy shapes: an operator must map them explicitly.
    IF collection_exists = 1 AND collection_column_count <> 5 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'account_transmog has an incompatible schema; migration stopped without changes.';
    END IF;
    IF tombstone_exists = 1 AND tombstone_column_count <> 2 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'account_transmog_removed_appearance has an incompatible schema; migration stopped without changes.';
    END IF;

    CREATE TABLE IF NOT EXISTS account_transmog_migrating_20260720 (
        account_id INT UNSIGNED NOT NULL,
        unlocked_item_id INT UNSIGNED NOT NULL,
        display_id INT UNSIGNED NOT NULL,
        inventory_type INT UNSIGNED NULL,
        item_name VARCHAR(255) NULL,
        PRIMARY KEY (account_id, unlocked_item_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

    CREATE TABLE IF NOT EXISTS account_transmog_removed_appearance_migrating_20260720 (
        account_id INT UNSIGNED NOT NULL,
        display_id INT UNSIGNED NOT NULL,
        PRIMARY KEY (account_id, display_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

    IF collection_exists = 1 THEN
        INSERT IGNORE INTO account_transmog_migrating_20260720
            (account_id, unlocked_item_id, display_id, inventory_type, item_name)
        SELECT account_id, unlocked_item_id, display_id, inventory_type, item_name
          FROM account_transmog;
    END IF;
    IF tombstone_exists = 1 THEN
        INSERT IGNORE INTO account_transmog_removed_appearance_migrating_20260720 (account_id, display_id)
        SELECT account_id, display_id FROM account_transmog_removed_appearance;
    END IF;

    -- Record whether the existing table already has the required persistence key.
    SELECT COUNT(*) INTO exact_collection_keys FROM (
        SELECT index_name FROM information_schema.statistics
         WHERE table_schema = current_database_name AND table_name = 'account_transmog' AND non_unique = 0
         GROUP BY index_name
        HAVING GROUP_CONCAT(column_name ORDER BY seq_in_index) = 'account_id,unlocked_item_id'
    ) AS collection_keys;
    SELECT COUNT(*) INTO exact_tombstone_keys FROM (
        SELECT index_name FROM information_schema.statistics
         WHERE table_schema = current_database_name AND table_name = 'account_transmog_removed_appearance' AND non_unique = 0
         GROUP BY index_name
        HAVING GROUP_CONCAT(column_name ORDER BY seq_in_index) = 'account_id,display_id'
    ) AS tombstone_keys;

    IF collection_exists = 1 AND exact_collection_keys = 0 THEN
        IF EXISTS (SELECT 1 FROM information_schema.tables
                   WHERE table_schema = current_database_name AND table_name = 'account_transmog_backup_20260720') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'account_transmog_backup_20260720 already exists; inspect it before retrying.';
        END IF;
        RENAME TABLE account_transmog TO account_transmog_backup_20260720,
                     account_transmog_migrating_20260720 TO account_transmog;
    ELSEIF collection_exists = 0 THEN
        RENAME TABLE account_transmog_migrating_20260720 TO account_transmog;
    ELSE
        DROP TABLE account_transmog_migrating_20260720;
    END IF;
    IF tombstone_exists = 1 AND exact_tombstone_keys = 0 THEN
        IF EXISTS (SELECT 1 FROM information_schema.tables
                   WHERE table_schema = current_database_name AND table_name = 'account_transmog_removed_appearance_backup_20260720') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'account_transmog_removed_appearance_backup_20260720 already exists; inspect it before retrying.';
        END IF;
        RENAME TABLE account_transmog_removed_appearance TO account_transmog_removed_appearance_backup_20260720,
                     account_transmog_removed_appearance_migrating_20260720 TO account_transmog_removed_appearance;
    ELSEIF tombstone_exists = 0 THEN
        RENAME TABLE account_transmog_removed_appearance_migrating_20260720 TO account_transmog_removed_appearance;
    ELSE
        DROP TABLE account_transmog_removed_appearance_migrating_20260720;
    END IF;
END$$
DELIMITER ;

CALL appearancebuddy_auth_migrate_20260720();
DROP PROCEDURE IF EXISTS appearancebuddy_auth_migrate_20260720;
