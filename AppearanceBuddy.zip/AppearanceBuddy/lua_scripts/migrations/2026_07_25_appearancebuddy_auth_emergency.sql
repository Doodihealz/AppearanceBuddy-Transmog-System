-- AppearanceBuddy emergency auth-schema repair.
-- Run this file against acore_auth only, with worldserver stopped.
-- It is safe after the broken pre-2026-07-25 package because it only creates
-- tables that do not already exist; it never changes existing rows or keys.

CREATE TABLE IF NOT EXISTS account_transmog (
    account_id INT UNSIGNED NOT NULL,
    unlocked_item_id INT UNSIGNED NOT NULL,
    display_id INT UNSIGNED NOT NULL,
    inventory_type INT UNSIGNED NULL,
    item_name VARCHAR(255) NULL,
    PRIMARY KEY (account_id, unlocked_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS account_transmog_removed_appearance (
    account_id INT UNSIGNED NOT NULL,
    display_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (account_id, display_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Both tables must appear here before restarting worldserver.
SHOW COLUMNS FROM account_transmog;
SHOW INDEX FROM account_transmog;
SHOW COLUMNS FROM account_transmog_removed_appearance;
SHOW INDEX FROM account_transmog_removed_appearance;
