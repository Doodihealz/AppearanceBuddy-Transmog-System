-- AppearanceBuddy emergency character-schema repair.
-- Run this file against acore_characters only, with worldserver stopped.
-- It is safe after the broken pre-2026-07-25 package because it only creates
-- tables that do not already exist; it never changes existing rows or keys.

CREATE TABLE IF NOT EXISTS character_transmog (
    player_guid INT UNSIGNED NOT NULL,
    slot SMALLINT UNSIGNED NOT NULL,
    item INT UNSIGNED NULL,
    real_item INT UNSIGNED NULL,
    PRIMARY KEY (player_guid, slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS character_transmog_weapon_enchant (
    player_guid INT UNSIGNED NOT NULL,
    equipment_slot TINYINT UNSIGNED NOT NULL,
    enchant_id SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (player_guid, equipment_slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Both tables must appear here before restarting worldserver.
SHOW COLUMNS FROM character_transmog;
SHOW INDEX FROM character_transmog;
SHOW COLUMNS FROM character_transmog_weapon_enchant;
SHOW INDEX FROM character_transmog_weapon_enchant;
