# AppearanceBuddy database migration

## Important 2026-07-25 automatic bootstrap

Discard any earlier AppearanceBuddy migration ZIP whose characters SQL declares
`state_unique_pair` twice. That SQL cannot create its procedure, so it leaves the
new tables missing and AppearanceBuddy correctly disables paid appearance changes.

The updated `transmog.lua` now safely detects missing tables through
`information_schema` at server startup and creates only the four absent
AppearanceBuddy tables. For the broken-package error, replace `transmog.lua`
and restart worldserver; no manual SQL is normally required.

Automatic setup never alters, drops, renames, or copies an existing table. That
protects existing appearance data, but means an old customized table, wrong
column type, or missing composite key still needs the reviewed offline migration.

## Manual fallback

Use the two simple recovery files only when the worldserver database account
lacks `CREATE TABLE`, or when you prefer to create the missing tables yourself:

1. Run `2026_07_25_appearancebuddy_auth_emergency.sql` with `acore_auth` selected.
2. Run `2026_07_25_appearancebuddy_characters_emergency.sql` with
   `acore_characters` selected.
3. Restart worldserver after both scripts complete.

Those recovery files only create missing tables. If worldserver still reports an
incompatible table or missing composite key after the restart, use the reviewed
2026-07-20 migration files below to rebuild a compatible legacy table safely.

Run these files once while the worldserver is stopped:

1. Run `2026_07_20_appearancebuddy_auth.sql` with `acore_auth` selected.
2. Run `2026_07_20_appearancebuddy_characters.sql` with `acore_characters` selected.

Use a normal database-client run **without `--force`**. Each file has an early
database guard and repeats it inside the procedure, so it will stop rather than
create AppearanceBuddy tables in the wrong database.

Before starting, take a normal database backup and record a **pre-migration
inventory** of any existing AppearanceBuddy tables, especially their row counts
and keys. The Lua bootstrap only creates absent tables; these offline migrations
retain the controlled rebuild path for existing legacy tables.

## What the migration does

The four canonical tables are:

- `account_transmog`
- `account_transmog_removed_appearance`
- `character_transmog`
- `character_transmog_weapon_enchant`

An already-canonical table is left unchanged. A compatible legacy table with an
old `id` column, redundant indexes, or a missing composite primary key is copied
to a fresh staging table, then activated by an atomic rename. The previous active
table stays available with a `_backup_20260720` suffix.

If legacy rows contain duplicate composite keys, the migration keeps the row with
the highest `id` only when `id` is verified as a unique unsigned auto-increment
selector. Otherwise it stops before changing anything. This prevents a silent,
arbitrary loss of an appearance or enchant choice.

## If the migration stops

Do not delete a staging or backup table just to rerun the file. Inspect it first.
For a manual recovery, make a separate copy of the affected source table and
label it clearly, for example `character_transmog_new_20260720` or
`character_transmog_weapon_enchant_new_20260720`. If a manual enchant recovery
copy is named `character_transmog_weapon_enchant_failed_20260720`, leave that untouched enchant table in place until its data has been compared with the active table and your pre-migration inventory.

The migration only knows how to rebuild compatible source columns. If an old
custom table has different columns, restore or map it manually instead of forcing
the migration through. Once both scripts report success, replace `transmog.lua`,
restart worldserver, and have players update the AppearanceBuddy addon.
