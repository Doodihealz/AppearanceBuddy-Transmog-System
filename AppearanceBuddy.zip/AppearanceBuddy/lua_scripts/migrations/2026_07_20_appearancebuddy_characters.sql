-- AppearanceBuddy character schema migration for acore_characters.
-- Stop worldserver first. Run this file with the acore_characters database
-- selected, and do not use a client --force option.

-- This non-persistent guard deliberately fails before the migration procedure
-- or any table DDL is created when the wrong database is selected. The
-- procedure repeats the check so a forced client cannot continue unsafely.
SET @appearancebuddy_characters_target_ok = (
    SELECT COUNT(*)
      FROM information_schema.tables
     WHERE table_schema = DATABASE()
       AND TABLE_NAME = 'characters'
       AND DATABASE() = 'acore_characters'
);
SET @appearancebuddy_characters_target_guard = IF(
    @appearancebuddy_characters_target_ok = 1,
    'SELECT ''AppearanceBuddy character target verified''',
    'APPEARANCEBUDDY_CHARACTERS_WRONG_DATABASE'
);
PREPARE appearancebuddy_characters_target_guard FROM @appearancebuddy_characters_target_guard;
EXECUTE appearancebuddy_characters_target_guard;
DEALLOCATE PREPARE appearancebuddy_characters_target_guard;

DROP PROCEDURE IF EXISTS appearancebuddy_characters_migrate_20260720;
DELIMITER $$
CREATE PROCEDURE appearancebuddy_characters_migrate_20260720()
BEGIN
    DECLARE current_database_name VARCHAR(64);
    DECLARE state_exists INT DEFAULT 0;
    DECLARE enchant_exists INT DEFAULT 0;
    DECLARE state_required_columns INT DEFAULT 0;
    DECLARE enchant_required_columns INT DEFAULT 0;
    DECLARE state_canonical_columns INT DEFAULT 0;
    DECLARE enchant_canonical_columns INT DEFAULT 0;
    DECLARE state_total_column_count INT DEFAULT 0;
    DECLARE enchant_total_column_count INT DEFAULT 0;
    DECLARE state_index_count INT DEFAULT 0;
    DECLARE enchant_index_count INT DEFAULT 0;
    DECLARE state_primary_pair INT DEFAULT 0;
    DECLARE enchant_primary_pair INT DEFAULT 0;
    DECLARE state_unique_pair INT DEFAULT 0;
    DECLARE enchant_unique_pair INT DEFAULT 0;
    DECLARE state_needs_rebuild INT DEFAULT 0;
    DECLARE enchant_needs_rebuild INT DEFAULT 0;
    DECLARE state_duplicate_pair_count INT DEFAULT 0;
    DECLARE enchant_duplicate_pair_count INT DEFAULT 0;
    DECLARE state_newest_id_selector INT DEFAULT 0;
    DECLARE enchant_newest_id_selector INT DEFAULT 0;

    SELECT DATABASE() INTO current_database_name;
    IF current_database_name IS NULL OR current_database_name <> 'acore_characters'
       OR NOT EXISTS (
            SELECT 1
              FROM information_schema.tables
             WHERE table_schema = current_database_name
               AND table_name = 'characters'
       ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'AppearanceBuddy character migration must be run against acore_characters.';
    END IF;

    SELECT COUNT(*) INTO state_exists
      FROM information_schema.tables
     WHERE table_schema = current_database_name
       AND table_name = 'character_transmog';
    SELECT COUNT(*) INTO enchant_exists
      FROM information_schema.tables
     WHERE table_schema = current_database_name
       AND table_name = 'character_transmog_weapon_enchant';

    IF state_exists = 1 THEN
        SELECT COUNT(*) INTO state_required_columns
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog'
           AND (
                (column_name = 'player_guid' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'slot' AND data_type IN ('smallint', 'mediumint', 'int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'item' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'real_item' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
           );
        SELECT COUNT(*) INTO state_canonical_columns
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog'
           AND (
                (column_name = 'player_guid' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'slot' AND data_type = 'smallint'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'item' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'YES')
             OR (column_name = 'real_item' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'YES')
           );
        SELECT COUNT(*) INTO state_total_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog';
    END IF;

    IF enchant_exists = 1 THEN
        SELECT COUNT(*) INTO enchant_required_columns
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog_weapon_enchant'
           AND (
                (column_name = 'player_guid' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'equipment_slot' AND data_type IN ('tinyint', 'smallint', 'mediumint', 'int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'enchant_id' AND data_type IN ('smallint', 'mediumint', 'int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
           );
        SELECT COUNT(*) INTO enchant_canonical_columns
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog_weapon_enchant'
           AND (
                (column_name = 'player_guid' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'equipment_slot' AND data_type = 'tinyint'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'enchant_id' AND data_type = 'smallint'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
           );
        SELECT COUNT(*) INTO enchant_total_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog_weapon_enchant';
    END IF;

    IF state_exists = 1 AND state_required_columns <> 4 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'character_transmog has missing or incompatible columns; migration stopped without changes.';
    END IF;
    IF enchant_exists = 1 THEN
        IF enchant_required_columns <> 3 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'character_transmog_weapon_enchant has missing or incompatible columns; migration stopped without changes.';
        END IF;
    END IF;

    IF state_exists = 1 THEN
        SELECT COUNT(*) INTO state_index_count
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'character_transmog'
                 GROUP BY index_name
          ) AS state_indexes;
        SELECT COUNT(*) INTO state_primary_pair
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'character_transmog'
                   AND index_name = 'PRIMARY'
                   AND non_unique = 0
                 GROUP BY index_name
                HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'player_guid,slot'
          ) AS state_primary_keys;
        SELECT COUNT(*) INTO state_unique_pair
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'character_transmog'
                   AND non_unique = 0
                 GROUP BY index_name
                HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'player_guid,slot'
          ) AS state_unique_keys;

        IF state_unique_pair > 0 THEN
            IF state_primary_pair > 0 AND state_index_count = 1
               AND state_canonical_columns = 4 AND state_total_column_count = 4 THEN
                SET state_needs_rebuild = 0;
            ELSE
                SET state_needs_rebuild = 1;
            END IF;
        ELSE
            SET state_needs_rebuild = 1;
        END IF;
    END IF;

    IF enchant_exists = 1 THEN
        SELECT COUNT(*) INTO enchant_index_count
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'character_transmog_weapon_enchant'
                 GROUP BY index_name
          ) AS enchant_indexes;
        SELECT COUNT(*) INTO enchant_primary_pair
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'character_transmog_weapon_enchant'
                   AND index_name = 'PRIMARY'
                   AND non_unique = 0
                 GROUP BY index_name
                HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'player_guid,equipment_slot'
          ) AS enchant_primary_keys;
        SELECT COUNT(*) INTO enchant_unique_pair
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'character_transmog_weapon_enchant'
                   AND non_unique = 0
                 GROUP BY index_name
                HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'player_guid,equipment_slot'
          ) AS enchant_unique_keys;

        IF enchant_unique_pair > 0 THEN
            IF enchant_primary_pair > 0 AND enchant_index_count = 1
               AND enchant_canonical_columns = 3 AND enchant_total_column_count = 3 THEN
                SET enchant_needs_rebuild = 0;
            ELSE
                SET enchant_needs_rebuild = 1;
            END IF;
        ELSE
            SET enchant_needs_rebuild = 1;
        END IF;
    END IF;

    -- Re-keyed legacy tables may have duplicate composite pairs. Select the
    -- newest row only when a unique unsigned AUTO_INCREMENT id proves what
    -- "newest" means; otherwise stop before any copy can lose a cosmetic.
    IF state_exists = 1 AND state_needs_rebuild = 1 THEN
        SELECT COUNT(*) INTO state_duplicate_pair_count
          FROM (
                SELECT player_guid, slot
                  FROM character_transmog
                 GROUP BY player_guid, slot
                HAVING COUNT(*) > 1
          ) AS duplicate_state_pairs;
        IF state_duplicate_pair_count > 0 THEN
            SELECT COUNT(*) INTO state_newest_id_selector
              FROM information_schema.columns AS columns_meta
              JOIN (
                    SELECT index_name
                      FROM information_schema.statistics
                     WHERE table_schema = current_database_name
                       AND table_name = 'character_transmog'
                       AND non_unique = 0
                     GROUP BY index_name
                    HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'id'
              ) AS selector_indexes ON 1 = 1
             WHERE columns_meta.table_schema = current_database_name
               AND columns_meta.table_name = 'character_transmog'
               AND columns_meta.column_name = 'id'
               AND columns_meta.data_type IN ('tinyint', 'smallint', 'mediumint', 'int', 'bigint')
               AND columns_meta.column_type LIKE '%unsigned%'
               AND columns_meta.extra LIKE '%auto_increment%';
            IF state_newest_id_selector = 0 THEN
                SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'character_transmog has duplicate slot rows without a safe newest-row id selector.';
            END IF;
        END IF;
    END IF;

    IF enchant_exists = 1 AND enchant_needs_rebuild = 1 THEN
        SELECT COUNT(*) INTO enchant_duplicate_pair_count
          FROM (
                SELECT player_guid, equipment_slot
                  FROM character_transmog_weapon_enchant
                 GROUP BY player_guid, equipment_slot
                HAVING COUNT(*) > 1
          ) AS duplicate_enchant_pairs;
        IF enchant_duplicate_pair_count > 0 THEN
            SELECT COUNT(*) INTO enchant_newest_id_selector
              FROM information_schema.columns AS columns_meta
              JOIN (
                    SELECT index_name
                      FROM information_schema.statistics
                     WHERE table_schema = current_database_name
                       AND table_name = 'character_transmog_weapon_enchant'
                       AND non_unique = 0
                     GROUP BY index_name
                    HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'id'
              ) AS selector_indexes ON 1 = 1
             WHERE columns_meta.table_schema = current_database_name
               AND columns_meta.table_name = 'character_transmog_weapon_enchant'
               AND columns_meta.column_name = 'id'
               AND columns_meta.data_type IN ('tinyint', 'smallint', 'mediumint', 'int', 'bigint')
               AND columns_meta.column_type LIKE '%unsigned%'
               AND columns_meta.extra LIKE '%auto_increment%';
            IF enchant_newest_id_selector = 0 THEN
                SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'character_transmog_weapon_enchant has duplicate slot rows without a safe newest-row id selector.';
            END IF;
        END IF;
    END IF;

    -- Never overwrite a recovery artifact. A clean retry starts with no
    -- migration/backup names other than backups from an already canonical run.
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
         WHERE table_schema = current_database_name
           AND table_name IN (
               'character_transmog_migrating_20260720',
               'character_transmog_weapon_enchant_migrating_20260720'
           )
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'AppearanceBuddy staging table already exists; inspect it before retrying.';
    END IF;
    IF (state_exists = 0 OR state_needs_rebuild = 1) AND EXISTS (
        SELECT 1 FROM information_schema.tables
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog_backup_20260720'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'character_transmog_backup_20260720 already exists; inspect it before retrying.';
    END IF;
    IF (enchant_exists = 0 OR enchant_needs_rebuild = 1) AND EXISTS (
        SELECT 1 FROM information_schema.tables
         WHERE table_schema = current_database_name
           AND table_name = 'character_transmog_weapon_enchant_backup_20260720'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'character_transmog_weapon_enchant_backup_20260720 already exists; inspect it before retrying.';
    END IF;

    CREATE TABLE character_transmog_migrating_20260720 (
        player_guid INT UNSIGNED NOT NULL,
        slot SMALLINT UNSIGNED NOT NULL,
        item INT UNSIGNED NULL,
        real_item INT UNSIGNED NULL,
        PRIMARY KEY (player_guid, slot)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    CREATE TABLE character_transmog_weapon_enchant_migrating_20260720 (
        player_guid INT UNSIGNED NOT NULL,
        equipment_slot TINYINT UNSIGNED NOT NULL,
        enchant_id SMALLINT UNSIGNED NOT NULL,
        PRIMARY KEY (player_guid, equipment_slot)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

    IF state_exists = 1 AND state_needs_rebuild = 1 THEN
        IF state_duplicate_pair_count > 0 THEN
            INSERT INTO character_transmog_migrating_20260720 (player_guid, slot, item, real_item)
            SELECT source.player_guid, source.slot, source.item, source.real_item
              FROM character_transmog AS source
              JOIN (
                    SELECT player_guid, slot, MAX(id) AS newest_id
                      FROM character_transmog
                     GROUP BY player_guid, slot
              ) AS newest
                ON newest.player_guid = source.player_guid
               AND newest.slot = source.slot
               AND newest.newest_id = source.id;
        ELSE
            INSERT INTO character_transmog_migrating_20260720 (player_guid, slot, item, real_item)
            SELECT player_guid, slot, item, real_item
              FROM character_transmog;
        END IF;
    END IF;

    IF enchant_exists = 1 AND enchant_needs_rebuild = 1 THEN
        IF enchant_duplicate_pair_count > 0 THEN
            INSERT INTO character_transmog_weapon_enchant_migrating_20260720
                (player_guid, equipment_slot, enchant_id)
            SELECT source.player_guid, source.equipment_slot, source.enchant_id
              FROM character_transmog_weapon_enchant AS source
              JOIN (
                    SELECT player_guid, equipment_slot, MAX(id) AS newest_id
                      FROM character_transmog_weapon_enchant
                     GROUP BY player_guid, equipment_slot
              ) AS newest
                ON newest.player_guid = source.player_guid
               AND newest.equipment_slot = source.equipment_slot
               AND newest.newest_id = source.id;
        ELSE
            INSERT INTO character_transmog_weapon_enchant_migrating_20260720
                (player_guid, equipment_slot, enchant_id)
            SELECT player_guid, equipment_slot, enchant_id
              FROM character_transmog_weapon_enchant;
        END IF;
    END IF;

    -- Build one RENAME TABLE statement so the paired schema activates atomically.
    SET @appearancebuddy_characters_rename_sql = NULL;
    IF state_exists = 1 AND state_needs_rebuild = 1 THEN
        SET @appearancebuddy_characters_rename_sql = 'RENAME TABLE ';
        SET @appearancebuddy_characters_rename_sql = CONCAT(
            @appearancebuddy_characters_rename_sql,
            'character_transmog TO character_transmog_backup_20260720, ',
            'character_transmog_migrating_20260720 TO character_transmog'
        );
    ELSEIF state_exists = 0 THEN
        SET @appearancebuddy_characters_rename_sql = 'RENAME TABLE ';
        SET @appearancebuddy_characters_rename_sql = CONCAT(
            @appearancebuddy_characters_rename_sql,
            'character_transmog_migrating_20260720 TO character_transmog'
        );
    END IF;

    IF enchant_exists = 1 AND enchant_needs_rebuild = 1 THEN
        IF @appearancebuddy_characters_rename_sql IS NULL THEN
            SET @appearancebuddy_characters_rename_sql = 'RENAME TABLE ';
        ELSE
            SET @appearancebuddy_characters_rename_sql = CONCAT(@appearancebuddy_characters_rename_sql, ', ');
        END IF;
        SET @appearancebuddy_characters_rename_sql = CONCAT(
            @appearancebuddy_characters_rename_sql,
            'character_transmog_weapon_enchant TO character_transmog_weapon_enchant_backup_20260720, ',
            'character_transmog_weapon_enchant_migrating_20260720 TO character_transmog_weapon_enchant'
        );
    ELSEIF enchant_exists = 0 THEN
        IF @appearancebuddy_characters_rename_sql IS NULL THEN
            SET @appearancebuddy_characters_rename_sql = 'RENAME TABLE ';
        ELSE
            SET @appearancebuddy_characters_rename_sql = CONCAT(@appearancebuddy_characters_rename_sql, ', ');
        END IF;
        SET @appearancebuddy_characters_rename_sql = CONCAT(
            @appearancebuddy_characters_rename_sql,
            'character_transmog_weapon_enchant_migrating_20260720 TO character_transmog_weapon_enchant'
        );
    END IF;

    IF @appearancebuddy_characters_rename_sql IS NOT NULL THEN
        PREPARE appearancebuddy_characters_rename FROM @appearancebuddy_characters_rename_sql;
        EXECUTE appearancebuddy_characters_rename;
        DEALLOCATE PREPARE appearancebuddy_characters_rename;
    END IF;

    -- These names only remain for unchanged canonical tables, because activated
    -- staging tables were renamed away above.
    DROP TABLE IF EXISTS character_transmog_migrating_20260720;
    DROP TABLE IF EXISTS character_transmog_weapon_enchant_migrating_20260720;
END$$
DELIMITER ;

CALL appearancebuddy_characters_migrate_20260720();
DROP PROCEDURE IF EXISTS appearancebuddy_characters_migrate_20260720;
