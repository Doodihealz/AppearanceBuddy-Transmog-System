-- AppearanceBuddy account schema migration for acore_auth.
-- Stop worldserver first. Run this file with the acore_auth database selected,
-- and do not use a client --force option.

-- This non-persistent guard fails before the migration procedure or table DDL
-- is created when the wrong database is selected. The procedure repeats the
-- check so a forced client cannot continue unsafely.
SET @appearancebuddy_auth_target_ok = (
    SELECT COUNT(*)
      FROM information_schema.tables
     WHERE table_schema = DATABASE()
       AND TABLE_NAME = 'account'
       AND DATABASE() = 'acore_auth'
);
SET @appearancebuddy_auth_target_guard = IF(
    @appearancebuddy_auth_target_ok = 1,
    'SELECT ''AppearanceBuddy auth target verified''',
    'APPEARANCEBUDDY_AUTH_WRONG_DATABASE'
);
PREPARE appearancebuddy_auth_target_guard FROM @appearancebuddy_auth_target_guard;
EXECUTE appearancebuddy_auth_target_guard;
DEALLOCATE PREPARE appearancebuddy_auth_target_guard;

DROP PROCEDURE IF EXISTS appearancebuddy_auth_migrate_20260720;
DELIMITER $$
CREATE PROCEDURE appearancebuddy_auth_migrate_20260720()
BEGIN
    DECLARE current_database_name VARCHAR(64);
    DECLARE collection_exists INT DEFAULT 0;
    DECLARE tombstone_exists INT DEFAULT 0;
    DECLARE collection_column_count INT DEFAULT 0;
    DECLARE tombstone_column_count INT DEFAULT 0;
    DECLARE collection_canonical_columns INT DEFAULT 0;
    DECLARE tombstone_canonical_columns INT DEFAULT 0;
    DECLARE collection_total_column_count INT DEFAULT 0;
    DECLARE tombstone_total_column_count INT DEFAULT 0;
    DECLARE collection_index_count INT DEFAULT 0;
    DECLARE tombstone_index_count INT DEFAULT 0;
    DECLARE collection_primary_pair INT DEFAULT 0;
    DECLARE tombstone_primary_pair INT DEFAULT 0;
    DECLARE exact_collection_keys INT DEFAULT 0;
    DECLARE exact_tombstone_keys INT DEFAULT 0;
    DECLARE collection_needs_rebuild INT DEFAULT 0;
    DECLARE tombstone_needs_rebuild INT DEFAULT 0;
    DECLARE collection_duplicate_pair_count INT DEFAULT 0;
    DECLARE collection_newest_id_selector INT DEFAULT 0;

    SELECT DATABASE() INTO current_database_name;
    IF current_database_name IS NULL OR current_database_name <> 'acore_auth'
       OR NOT EXISTS (
            SELECT 1
              FROM information_schema.tables
             WHERE table_schema = current_database_name
               AND table_name = 'account'
       ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'AppearanceBuddy auth migration must be run against acore_auth.';
    END IF;

    SELECT COUNT(*) INTO collection_exists
      FROM information_schema.tables
     WHERE table_schema = current_database_name
       AND table_name = 'account_transmog';
    SELECT COUNT(*) INTO tombstone_exists
      FROM information_schema.tables
     WHERE table_schema = current_database_name
       AND table_name = 'account_transmog_removed_appearance';

    IF collection_exists = 1 THEN
        SELECT COUNT(*) INTO collection_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog'
           AND (
                (column_name = 'account_id' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'unlocked_item_id' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'display_id' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'inventory_type' AND data_type IN ('tinyint', 'smallint', 'mediumint', 'int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'item_name' AND (
                    (data_type IN ('varchar', 'char') AND character_maximum_length >= 255)
                    OR data_type IN ('tinytext', 'text', 'mediumtext', 'longtext')
                ))
           );
        SELECT COUNT(*) INTO collection_canonical_columns
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog'
           AND (
                (column_name = 'account_id' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'unlocked_item_id' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'display_id' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'inventory_type' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'YES')
             OR (column_name = 'item_name' AND data_type = 'varchar'
                    AND character_maximum_length >= 255 AND is_nullable = 'YES')
           );
        SELECT COUNT(*) INTO collection_total_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog';
    END IF;

    IF tombstone_exists = 1 THEN
        SELECT COUNT(*) INTO tombstone_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog_removed_appearance'
           AND (
                (column_name = 'account_id' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
             OR (column_name = 'display_id' AND data_type IN ('int', 'integer', 'bigint')
                    AND column_type LIKE '%unsigned%')
           );
        SELECT COUNT(*) INTO tombstone_canonical_columns
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog_removed_appearance'
           AND (
                (column_name = 'account_id' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
             OR (column_name = 'display_id' AND data_type = 'int'
                    AND column_type LIKE '%unsigned%' AND is_nullable = 'NO')
           );
        SELECT COUNT(*) INTO tombstone_total_column_count
          FROM information_schema.columns
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog_removed_appearance';
    END IF;

    IF collection_exists = 1 AND collection_column_count <> 5 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'account_transmog has missing or incompatible columns; migration stopped without changes.';
    END IF;
    IF tombstone_exists = 1 THEN
        IF tombstone_column_count <> 2 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'account_transmog_removed_appearance has missing or incompatible columns; migration stopped without changes.';
        END IF;
    END IF;

    IF collection_exists = 1 THEN
        SELECT COUNT(*) INTO collection_index_count
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'account_transmog'
                 GROUP BY index_name
          ) AS collection_indexes;
        SELECT COUNT(*) INTO collection_primary_pair
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'account_transmog'
                   AND index_name = 'PRIMARY'
                   AND non_unique = 0
                 GROUP BY index_name
                HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'account_id,unlocked_item_id'
          ) AS collection_primary_keys;
        IF collection_primary_pair > 0
           AND collection_index_count = 1
           AND collection_canonical_columns = 5
           AND collection_total_column_count = 5 THEN
            SET exact_collection_keys = 1;
        END IF;
        IF exact_collection_keys = 0 THEN
            SET collection_needs_rebuild = 1;
        END IF;
    END IF;

    IF tombstone_exists = 1 THEN
        SELECT COUNT(*) INTO tombstone_index_count
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'account_transmog_removed_appearance'
                 GROUP BY index_name
          ) AS tombstone_indexes;
        SELECT COUNT(*) INTO tombstone_primary_pair
          FROM (
                SELECT index_name
                  FROM information_schema.statistics
                 WHERE table_schema = current_database_name
                   AND table_name = 'account_transmog_removed_appearance'
                   AND index_name = 'PRIMARY'
                   AND non_unique = 0
                 GROUP BY index_name
                HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'account_id,display_id'
          ) AS tombstone_primary_keys;
        IF tombstone_primary_pair > 0
           AND tombstone_index_count = 1
           AND tombstone_canonical_columns = 2
           AND tombstone_total_column_count = 2 THEN
            SET exact_tombstone_keys = 1;
        END IF;
        IF exact_tombstone_keys = 0 THEN
            SET tombstone_needs_rebuild = 1;
        END IF;
    END IF;

    -- A collection row carries display/name data, so duplicate legacy pairs
    -- need an auditable newest-row selector. Tombstone duplicates carry no
    -- payload and are copied with SELECT DISTINCT below.
    IF collection_exists = 1 AND collection_needs_rebuild = 1 THEN
        SELECT COUNT(*) INTO collection_duplicate_pair_count
          FROM (
                SELECT account_id, unlocked_item_id
                  FROM account_transmog
                 GROUP BY account_id, unlocked_item_id
                HAVING COUNT(*) > 1
          ) AS duplicate_collection_pairs;
        IF collection_duplicate_pair_count > 0 THEN
            SELECT COUNT(*) INTO collection_newest_id_selector
              FROM information_schema.columns AS columns_meta
              JOIN (
                    SELECT index_name
                      FROM information_schema.statistics
                     WHERE table_schema = current_database_name
                       AND table_name = 'account_transmog'
                       AND non_unique = 0
                     GROUP BY index_name
                    HAVING GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) = 'id'
              ) AS selector_indexes ON 1 = 1
             WHERE columns_meta.table_schema = current_database_name
               AND columns_meta.table_name = 'account_transmog'
               AND columns_meta.column_name = 'id'
               AND columns_meta.data_type IN ('tinyint', 'smallint', 'mediumint', 'int', 'bigint')
               AND columns_meta.column_type LIKE '%unsigned%'
               AND columns_meta.extra LIKE '%auto_increment%';
            IF collection_newest_id_selector = 0 THEN
                SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'account_transmog has duplicate rows without a safe newest-row id selector.';
            END IF;
        END IF;
    END IF;

    -- Never merge stale staging rows or overwrite a recovery backup.
    IF EXISTS (
        SELECT 1 FROM information_schema.tables
         WHERE table_schema = current_database_name
           AND table_name IN (
               'account_transmog_migrating_20260720',
               'account_transmog_removed_appearance_migrating_20260720'
           )
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'AppearanceBuddy staging table already exists; inspect it before retrying.';
    END IF;
    IF (collection_exists = 0 OR collection_needs_rebuild = 1) AND EXISTS (
        SELECT 1 FROM information_schema.tables
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog_backup_20260720'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'account_transmog_backup_20260720 already exists; inspect it before retrying.';
    END IF;
    IF (tombstone_exists = 0 OR tombstone_needs_rebuild = 1) AND EXISTS (
        SELECT 1 FROM information_schema.tables
         WHERE table_schema = current_database_name
           AND table_name = 'account_transmog_removed_appearance_backup_20260720'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'account_transmog_removed_appearance_backup_20260720 already exists; inspect it before retrying.';
    END IF;

    CREATE TABLE account_transmog_migrating_20260720 (
        account_id INT UNSIGNED NOT NULL,
        unlocked_item_id INT UNSIGNED NOT NULL,
        display_id INT UNSIGNED NOT NULL,
        inventory_type INT UNSIGNED NULL,
        item_name VARCHAR(255) NULL,
        PRIMARY KEY (account_id, unlocked_item_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    CREATE TABLE account_transmog_removed_appearance_migrating_20260720 (
        account_id INT UNSIGNED NOT NULL,
        display_id INT UNSIGNED NOT NULL,
        PRIMARY KEY (account_id, display_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

    IF collection_exists = 1 AND collection_needs_rebuild = 1 THEN
        IF collection_duplicate_pair_count > 0 THEN
            INSERT INTO account_transmog_migrating_20260720
                (account_id, unlocked_item_id, display_id, inventory_type, item_name)
            SELECT source.account_id, source.unlocked_item_id, source.display_id,
                   source.inventory_type, source.item_name
              FROM account_transmog AS source
              JOIN (
                    SELECT account_id, unlocked_item_id, MAX(id) AS newest_id
                      FROM account_transmog
                     GROUP BY account_id, unlocked_item_id
              ) AS newest
                ON newest.account_id = source.account_id
               AND newest.unlocked_item_id = source.unlocked_item_id
               AND newest.newest_id = source.id;
        ELSE
            INSERT INTO account_transmog_migrating_20260720
                (account_id, unlocked_item_id, display_id, inventory_type, item_name)
            SELECT account_id, unlocked_item_id, display_id, inventory_type, item_name
              FROM account_transmog;
        END IF;
    END IF;

    IF tombstone_exists = 1 AND tombstone_needs_rebuild = 1 THEN
        INSERT INTO account_transmog_removed_appearance_migrating_20260720
            (account_id, display_id)
        SELECT DISTINCT account_id, display_id
          FROM account_transmog_removed_appearance;
    END IF;

    -- Build one RENAME TABLE statement so both auth tables activate atomically.
    SET @appearancebuddy_auth_rename_sql = NULL;
    IF collection_exists = 1 AND collection_needs_rebuild = 1 THEN
        SET @appearancebuddy_auth_rename_sql = 'RENAME TABLE ';
        SET @appearancebuddy_auth_rename_sql = CONCAT(
            @appearancebuddy_auth_rename_sql,
            'account_transmog TO account_transmog_backup_20260720, ',
            'account_transmog_migrating_20260720 TO account_transmog'
        );
    ELSEIF collection_exists = 0 THEN
        SET @appearancebuddy_auth_rename_sql = 'RENAME TABLE ';
        SET @appearancebuddy_auth_rename_sql = CONCAT(
            @appearancebuddy_auth_rename_sql,
            'account_transmog_migrating_20260720 TO account_transmog'
        );
    END IF;

    IF tombstone_exists = 1 AND tombstone_needs_rebuild = 1 THEN
        IF @appearancebuddy_auth_rename_sql IS NULL THEN
            SET @appearancebuddy_auth_rename_sql = 'RENAME TABLE ';
        ELSE
            SET @appearancebuddy_auth_rename_sql = CONCAT(@appearancebuddy_auth_rename_sql, ', ');
        END IF;
        SET @appearancebuddy_auth_rename_sql = CONCAT(
            @appearancebuddy_auth_rename_sql,
            'account_transmog_removed_appearance TO account_transmog_removed_appearance_backup_20260720, ',
            'account_transmog_removed_appearance_migrating_20260720 TO account_transmog_removed_appearance'
        );
    ELSEIF tombstone_exists = 0 THEN
        IF @appearancebuddy_auth_rename_sql IS NULL THEN
            SET @appearancebuddy_auth_rename_sql = 'RENAME TABLE ';
        ELSE
            SET @appearancebuddy_auth_rename_sql = CONCAT(@appearancebuddy_auth_rename_sql, ', ');
        END IF;
        SET @appearancebuddy_auth_rename_sql = CONCAT(
            @appearancebuddy_auth_rename_sql,
            'account_transmog_removed_appearance_migrating_20260720 TO account_transmog_removed_appearance'
        );
    END IF;

    IF @appearancebuddy_auth_rename_sql IS NOT NULL THEN
        PREPARE appearancebuddy_auth_rename FROM @appearancebuddy_auth_rename_sql;
        EXECUTE appearancebuddy_auth_rename;
        DEALLOCATE PREPARE appearancebuddy_auth_rename;
    END IF;

    DROP TABLE IF EXISTS account_transmog_migrating_20260720;
    DROP TABLE IF EXISTS account_transmog_removed_appearance_migrating_20260720;
END$$
DELIMITER ;

CALL appearancebuddy_auth_migrate_20260720();
DROP PROCEDURE IF EXISTS appearancebuddy_auth_migrate_20260720;
