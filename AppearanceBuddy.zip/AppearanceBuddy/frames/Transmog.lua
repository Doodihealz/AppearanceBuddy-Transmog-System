local addon, ns = ...

local mainFrame = ns.mainFrame
if not mainFrame or not mainFrame.tabs or not mainFrame.tabs.transmog then
    return
end

local AIO = _G.AIO
if not AIO and type(require) == "function" then
    local ok, lib = pcall(require, "AIO")
    if ok then
        AIO = lib
    end
end

local GetSettings = ns.GetSettings
local transmogTab = mainFrame.tabs.transmog
local transmogTabName = transmogTab:GetName() or (addon.."TransmogTab")

local SLOT_DATA = {
    { name = "Head", slotId = 283, previewSubclass = nil },
    { name = "Shoulder", slotId = 287, previewSubclass = nil },
    { name = "Back", slotId = 311, previewSubclass = "Cloth" },
    { name = "Chest", slotId = 291, previewSubclass = nil },
    { name = "Shirt", slotId = 289, previewSubclass = "Miscellaneous" },
    { name = "Tabard", slotId = 319, previewSubclass = "Miscellaneous" },
    { name = "Wrist", slotId = 299, previewSubclass = nil },
    { name = "Hands", slotId = 301, previewSubclass = nil },
    { name = "Waist", slotId = 293, previewSubclass = nil },
    { name = "Legs", slotId = 295, previewSubclass = nil },
    { name = "Feet", slotId = 297, previewSubclass = nil },
    { name = "Main Hand", slotId = 313, previewSubclass = "1H Sword" },
    { name = "Off-hand", slotId = 315, previewSubclass = "Shield" },
    { name = "Ranged", slotId = 317, previewSubclass = "Bow" },
}

local DEFAULT_ARMOR_SUBCLASS = {
    ["MAGE"] = "Cloth",
    ["PRIEST"] = "Cloth",
    ["WARLOCK"] = "Cloth",
    ["DRUID"] = "Leather",
    ["ROGUE"] = "Leather",
    ["HUNTER"] = "Mail",
    ["SHAMAN"] = "Mail",
    ["PALADIN"] = "Plate",
    ["WARRIOR"] = "Plate",
    ["DEATHKNIGHT"] = "Plate",
}

local SLOT_ID_BY_NAME = {}
local SLOT_NAME_BY_ID = {}
local SLOT_PREVIEW_SUBCLASS = {}

for _, info in ipairs(SLOT_DATA) do
    SLOT_ID_BY_NAME[info.name] = info.slotId
    SLOT_NAME_BY_ID[info.slotId] = info.name
    SLOT_PREVIEW_SUBCLASS[info.name] = info.previewSubclass
end

local _, playerRaceFileName = UnitRace("player")
local playerSex = UnitSex("player")
local _, playerClassFileName = UnitClass("player")

local ACTION_ROW_Y = 8
local STATUS_ROW_Y = 32
local LIST_TOP_Y = -56
local LIST_BOTTOM_Y = 52
local SETS_FRAME_BOTTOM_Y = 10
local SETS_SCROLL_STEP = 72
local SETS_LIST_SCROLL_WIDTH = 332
local SETS_LIST_WIDTH = 308
local SETS_PREVIEW_LEFT_X = 380
local SETS_AUTO_REFRESH_INTERVAL = 120
local SETS_DIRTY_REFRESH_DELAY = 2
local DEFAULT_TRANSMOG_PAGE_SIZE = 10

local PREVIEW_CARD_LAYOUT = {
    armor = {
        width = 122,
        height = 98,
    },
    weapon = {
        width = 122,
        height = 98,
    },
}

local WEAPON_SLOT = {
    ["Main Hand"] = true,
    ["Off-hand"] = true,
    ["Ranged"] = true,
}

local SET_LIST_ICON_SLOT_PRIORITY = {1, 2, 4, 8, 9, 10, 11, 7, 3, 5, 6, 12, 13, 14}
local SET_PREVIEW_RETRY_SLOT_ORDER = {
    "Chest", "Legs", "Feet", "Waist", "Hands", "Wrist",
    "Back", "Shoulder", "Head", "Shirt", "Tabard",
    "Main Hand", "Off-hand", "Ranged",
}

local INVENTORY_TOKEN_BY_SLOT_NAME = {
    ["Head"] = "Head",
    ["Shoulder"] = "Shoulder",
    ["Back"] = "Back",
    ["Chest"] = "Chest",
    ["Shirt"] = "Shirt",
    ["Tabard"] = "Tabard",
    ["Wrist"] = "Wrist",
    ["Hands"] = "Hands",
    ["Waist"] = "Waist",
    ["Legs"] = "Legs",
    ["Feet"] = "Feet",
    ["Main Hand"] = "MainHand",
    ["Off-hand"] = "SecondaryHand",
    ["Ranged"] = "Ranged",
}

local SET_SOURCE_SAVED = "saved"
local SET_SOURCE_CATALOG = "catalog"

local function trim(text)
    text = tostring(text or "")
    text = text:gsub("^%s+", "")
    text = text:gsub("%s+$", "")
    return text
end

local function safeLink(itemId)
    local _, link = GetItemInfo(itemId)
    return link
end

local appearanceKeyCacheBySlot = {}

local function getAppearanceKey(slotName, itemId)
    local numericItemId = tonumber(itemId)
    if not slotName or not numericItemId or numericItemId <= 0 then
        return nil
    end

    local slotCache = appearanceKeyCacheBySlot[slotName]
    if not slotCache then
        slotCache = {}
        appearanceKeyCacheBySlot[slotName] = slotCache
    end

    if slotCache[numericItemId] ~= nil then
        return slotCache[numericItemId]
    end

    local key = "item:"..numericItemId
    if type(ns.FindRecord) == "function" then
        local ids = ns.FindRecord(slotName, numericItemId)
        if type(ids) == "table" and tonumber(ids[1]) then
            key = "appearance:"..tonumber(ids[1])
        end
    end

    slotCache[numericItemId] = key
    return key
end

local function dedupeItemIdsByAppearance(slotName, itemIds)
    local uniqueItemIds = {}
    local seenAppearanceKeys = {}

    for index = 1, #(itemIds or {}) do
        local itemId = tonumber(itemIds[index])
        if itemId and itemId > 0 then
            local appearanceKey = getAppearanceKey(slotName, itemId) or ("item:"..itemId)
            if not seenAppearanceKeys[appearanceKey] then
                seenAppearanceKeys[appearanceKey] = true
                uniqueItemIds[#uniqueItemIds + 1] = itemId
            end
        end
    end

    return uniqueItemIds
end

local function getDisplayedItemIdForAppearance(slotName, selectedItemId, displayedItemIds)
    local numericItemId = tonumber(selectedItemId)
    if not slotName or not numericItemId or numericItemId <= 0 then
        return nil
    end

    local selectedAppearanceKey = getAppearanceKey(slotName, numericItemId)
    if not selectedAppearanceKey then
        return nil
    end

    for index = 1, #(displayedItemIds or {}) do
        local displayedItemId = tonumber(displayedItemIds[index])
        if displayedItemId == numericItemId then
            return displayedItemId
        end

        if displayedItemId and getAppearanceKey(slotName, displayedItemId) == selectedAppearanceKey then
            return displayedItemId
        end
    end

    return nil
end

local function getEquippedVisibleItemId(slotName)
    local inventoryToken = INVENTORY_TOKEN_BY_SLOT_NAME[slotName]
    if not inventoryToken then
        return nil
    end

    local inventorySlot = GetInventorySlotInfo(inventoryToken.."Slot")
    if not inventorySlot then
        return nil
    end

    local itemId = GetInventoryItemID("player", inventorySlot)
    return tonumber(itemId) or nil
end

local function getSavedTransmogSets()
    -- Migrate from old DressMe variable name.
    -- Also migrate if AppearanceBuddyTransmogSavedSets is an empty table but
    -- DressMeTransmogSavedSets has entries (handles the case where a previous
    -- session wrote an empty table before migration had a chance to run).
    local existing = _G.AppearanceBuddyTransmogSavedSets
    local legacy   = _G.DressMeTransmogSavedSets
    local needMigrate = type(existing) ~= "table"
        or (type(legacy) == "table" and #legacy > 0 and #existing == 0)
    if needMigrate then
        if type(legacy) == "table" and #legacy > 0 then
            _G.AppearanceBuddyTransmogSavedSets = legacy
            _G.DressMeTransmogSavedSets = nil
        elseif type(existing) ~= "table" then
            _G.AppearanceBuddyTransmogSavedSets = {}
        end
    end

    return _G.AppearanceBuddyTransmogSavedSets
end

local function sortSavedTransmogSets()
    table.sort(getSavedTransmogSets(), function(a, b)
        local nameA = tostring(a and a.name or "")
        local nameB = tostring(b and b.name or "")
        if nameA == nameB then
            return false
        end
        return nameA < nameB
    end)
end

local function normalizeServerState(itemId, realItemId, slotName)
    local item = tonumber(itemId)
    local real = tonumber(realItemId)

    if (not real or real <= 0) and slotName then
        real = getEquippedVisibleItemId(slotName)
    end

    if real == 0 then
        real = nil
    end

    local effectiveId
    if item == 0 then
        effectiveId = 0
    elseif item and item > 0 then
        effectiveId = item
    else
        effectiveId = real
    end

    return {
        itemId = item,
        realItemId = real,
        effectiveId = effectiveId,
    }
end

local state = {
    enabled = AIO and type(AIO.AddHandlers) == "function" and type(AIO.Handle) == "function",
    disabledReason = nil,
    applyingAppearanceSet = false,
    applyingUnlockedItemSet = false,
    synced = false,
    currentSlot = SLOT_DATA[1].name,
    currentPage = 1,
    hasMorePages = false,
    requestToken = 0,
    search = "",
    viewMode = "items",
    setSource = SET_SOURCE_SAVED,
    itemSetCatalog = {},
    itemSetCatalogLoaded = false,
    itemSetCatalogRequestPending = false,
    itemSetCatalogRequestStartedAt = 0,
    itemSetCatalogLastRefreshAt = 0,
    itemSetCatalogDirty = true,
    itemSetCatalogDirtyAt = 0,
    selectedSavedSetName = nil,
    selectedCatalogSetId = nil,
    slotPages = {},
    slotPageAnchors = {},
    pageLookupToken = 0,
    pageLookupSlot = nil,
    pageLookupAnchor = nil,
    previousUnit = nil,
    previousView = nil,
    unobtainedPage = 1,
    unobtainedHasMorePages = false,
    unobtainedRequestToken = 0,
    unobtainedSearch = "",
    unobtainedSlotPages = {},
    server = {},
    preview = {},
    slotButtons = {},
}

for _, info in ipairs(SLOT_DATA) do
    state.server[info.name] = normalizeServerState(nil, nil)
    state.preview[info.name] = {
        mode = "restore",
        itemId = nil,
        effectiveId = nil,
    }
end

local function slotHasRestorableAppearance(slotName)
    local serverState = slotName and state.server[slotName]
    local realItemId = serverState and tonumber(serverState.realItemId) or nil
    return realItemId and realItemId > 0
end

local function copyServerToPreview(slotName)
    local serverState = state.server[slotName]
    local previewState = state.preview[slotName]

    previewState.itemId = nil

    if serverState.itemId == 0 then
        previewState.mode = "hidden"
        previewState.effectiveId = 0
    elseif serverState.itemId and serverState.itemId > 0 then
        previewState.mode = "item"
        previewState.itemId = serverState.itemId
        previewState.effectiveId = serverState.itemId
    else
        previewState.mode = "restore"
        previewState.effectiveId = serverState.realItemId
    end
end

local function copyAllServerToPreview()
    for _, info in ipairs(SLOT_DATA) do
        copyServerToPreview(info.name)
    end
end

local function snapshotCurrentTransmogSet()
    local items = {}

    for index, info in ipairs(SLOT_DATA) do
        local previewState = state.preview[info.name]
        if previewState.mode == "hidden" then
            items[index] = 0
        elseif previewState.mode == "item" and previewState.itemId then
            items[index] = previewState.itemId
        else
            items[index] = slotHasRestorableAppearance(info.name) and -1 or 0
        end
    end

    return items
end

local function getTransmogSetPreviewItem(index, itemIds)
    local requestedItemId = type(itemIds) == "table" and tonumber(itemIds[index]) or nil
    local slotName = SLOT_DATA[index] and SLOT_DATA[index].name or nil

    if requestedItemId and requestedItemId > 0 then
        return requestedItemId
    end

    if requestedItemId == 0 then
        return 0
    end

    if slotName and state.server[slotName] and state.server[slotName].realItemId then
        return state.server[slotName].realItemId
    end

    return 0
end

local function buildPreviewItemsFromTransmogSet(itemIds)
    local previewItems = {}

    for index = 1, #SLOT_DATA do
        previewItems[index] = getTransmogSetPreviewItem(index, itemIds)
    end

    return previewItems
end

local function ensureSetPreviewBackground(model)
    if not model or not model.backgroundTextures then
        return
    end

    for _, texture in pairs(model.backgroundTextures) do
        texture:Hide()
    end
end

local function updateSetPreviewBackground()
    local setsFrame = transmogTab and transmogTab.setsFrame
    local model = setsFrame and setsFrame.previewModel
    ensureSetPreviewBackground(model)
end

local function getSetListIconItemId(setData)
    if type(setData) ~= "table" then
        return nil
    end

    for _, slotIndex in ipairs(SET_LIST_ICON_SLOT_PRIORITY) do
        local unlockedItemId = type(setData.unlockedItems) == "table" and tonumber(setData.unlockedItems[slotIndex]) or nil
        if unlockedItemId and unlockedItemId > 0 then
            return unlockedItemId
        end

        local previewItemId = type(setData.fullItems) == "table" and tonumber(setData.fullItems[slotIndex]) or nil
        if previewItemId and previewItemId > 0 then
            return previewItemId
        end

        local savedItemId = type(setData.items) == "table" and tonumber(setData.items[slotIndex]) or nil
        if savedItemId and savedItemId > 0 then
            return savedItemId
        end
    end

    return nil
end

local function ensureSetListButtonLayout(button)
    if not button then
        return nil
    end

    if not button.iconTexture then
        button.iconTexture = button:CreateTexture(nil, "ARTWORK")
        button.iconTexture:SetSize(16, 16)
        button.iconTexture:SetPoint("LEFT", button, "LEFT", 4, 0)
        button.iconTexture:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        button.iconTexture:Hide()

        button.iconBackdrop = button:CreateTexture(nil, "BACKGROUND")
        button.iconBackdrop:SetPoint("TOPLEFT", button.iconTexture, "TOPLEFT", -1, 1)
        button.iconBackdrop:SetPoint("BOTTOMRIGHT", button.iconTexture, "BOTTOMRIGHT", 1, -1)
        button.iconBackdrop:SetTexture("Interface\\Buttons\\WHITE8X8")
        button.iconBackdrop:SetVertexColor(0.12, 0.12, 0.12, 0.85)
        button.iconBackdrop:Hide()
    end

    local label = button:GetFontString()
    if label then
        label:ClearAllPoints()
        if button.iconTexture:IsShown() then
            label:SetPoint("LEFT", button.iconTexture, "RIGHT", 4, 0)
        else
            label:SetPoint("LEFT", button, "LEFT", 6, 0)
        end
        label:SetPoint("RIGHT", button, "RIGHT", -2, 0)
        label:SetJustifyH("LEFT")
    end

    return label
end

local function setSetListButtonIcon(button, itemId)
    if not button then
        return
    end

    ensureSetListButtonLayout(button)
    itemId = tonumber(itemId) or 0
    button.catalogIconItemId = itemId

    if itemId <= 0 then
        if button.iconTexture then
            button.iconTexture:Hide()
        end
        if button.iconBackdrop then
            button.iconBackdrop:Hide()
        end
        ensureSetListButtonLayout(button)
        return
    end

    if button.iconBackdrop then
        button.iconBackdrop:Show()
    end
    if button.iconTexture then
        button.iconTexture:Show()
        button.iconTexture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    end
    ensureSetListButtonLayout(button)

    local _, _, _, _, _, _, _, _, _, texture = GetItemInfo(itemId)
    if texture then
        if button.catalogIconItemId == itemId and button.iconTexture then
            button.iconTexture:SetTexture(texture)
        end
        return
    end

    ns.QueryItem(itemId, function(queriedItemId, success)
        if not success or not button or button.catalogIconItemId ~= queriedItemId then
            return
        end

        local _, _, _, _, _, _, _, _, _, queriedTexture = GetItemInfo(queriedItemId)
        if queriedTexture and button.iconTexture then
            button.iconTexture:SetTexture(queriedTexture)
        end
    end)
end

local function ensureSetListButtonTooltip(button)
    if not button or button.fullLabelTooltipHooked then
        return
    end

    button:HookScript("OnEnter", function(self)
        local fullText = self.fullLabelText
        if not fullText or fullText == "" then
            return
        end

        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(fullText, 1, 0.82, 0)
        GameTooltip:Show()
    end)

    button:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    button.fullLabelTooltipHooked = true
end

local function getCurrentSlotPageAnchor(slotName)
    local previewState = state.preview[slotName]
    local serverState = state.server[slotName]

    if previewState and previewState.mode == "item" and previewState.itemId and previewState.itemId > 0 then
        return previewState.itemId
    end

    if previewState and previewState.mode == "hidden" then
        return 0
    end

    if serverState and serverState.itemId and serverState.itemId > 0 then
        return serverState.itemId
    end

    if serverState and serverState.itemId == 0 then
        return 0
    end

    if previewState and previewState.effectiveId and previewState.effectiveId > 0 then
        return previewState.effectiveId
    end

    if serverState and serverState.realItemId and serverState.realItemId > 0 then
        return serverState.realItemId
    end

    return 0
end

local function rememberSlotPage(slotName, page, anchor)
    slotName = slotName or state.currentSlot
    if not slotName then
        return
    end

    page = tonumber(page) or 1
    if page < 1 then
        page = 1
    end

    if anchor == nil then
        anchor = getCurrentSlotPageAnchor(slotName)
    end

    state.slotPages[slotName] = page
    state.slotPageAnchors[slotName] = tonumber(anchor) or 0
end

local function isSlotDirty(slotName)
    local serverState = state.server[slotName]
    local previewState = state.preview[slotName]

    if previewState.mode == "restore" then
        return serverState.itemId ~= nil
    elseif previewState.mode == "hidden" then
        return serverState.itemId ~= 0
    elseif previewState.mode == "item" then
        return serverState.itemId ~= previewState.itemId
    end

    return false
end

local function getDirtyCount()
    local total = 0
    for _, info in ipairs(SLOT_DATA) do
        if isSlotDirty(info.name) then
            total = total + 1
        end
    end
    return total
end

local function hasAppliedTransmogs()
    for _, info in ipairs(SLOT_DATA) do
        if state.server[info.name].itemId ~= nil then
            return true
        end
    end

    return false
end

local function getPreviewSetup(slotName)
    local subclass = SLOT_PREVIEW_SUBCLASS[slotName] or DEFAULT_ARMOR_SUBCLASS[playerClassFileName]
    local version = ns.GetPreviewSetupVersion and ns.GetPreviewSetupVersion() or "classic"
    return ns.GetPreviewSetup(version, playerRaceFileName, playerSex, slotName, subclass)
end

-- Per-slot model scale for the preview grid cells.
-- 1.0 = full character visible, 3.0 = only ~1/3 of the body fills the cell, etc.
local SLOT_MODEL_SCALE = {
    ["Head"]      = 3.5,
    ["Shoulder"]  = 3.0,
    ["Back"]      = 3.0,
    ["Chest"]     = 2.5,
    ["Shirt"]     = 2.5,
    ["Tabard"]    = 2.5,
    ["Wrist"]     = 3.5,
    ["Hands"]     = 3.5,
    ["Waist"]     = 3.0,
    ["Legs"]      = 2.5,
    ["Feet"]      = 3.5,
    ["Main Hand"] = 2.5,
    ["Off-hand"]  = 2.5,
    ["Ranged"]    = 2.5,
}

local function getListPreviewSetup(slotName)
    local baseSetup = getPreviewSetup(slotName) or {}
    local layout = WEAPON_SLOT[slotName] and PREVIEW_CARD_LAYOUT.weapon or PREVIEW_CARD_LAYOUT.armor
    local modelScale = SLOT_MODEL_SCALE[slotName] or 1.0

    return layout.width,
        layout.height,
        tonumber(baseSetup.x) or 0,
        tonumber(baseSetup.y) or 0,
        tonumber(baseSetup.z) or 0,
        tonumber(baseSetup.sequence) or 3,
        modelScale
end

local function getCurrentSlotPageSize(slotName)
    local width, height = getListPreviewSetup(slotName)
    width = tonumber(width) or 0
    height = tonumber(height) or 0

    if width <= 0 or height <= 0 then
        return DEFAULT_TRANSMOG_PAGE_SIZE
    end

    local listWidth = tonumber(transmogTab.list and transmogTab.list:GetWidth()) or 0
    local listHeight = tonumber(transmogTab.list and transmogTab.list:GetHeight()) or 0
    if listWidth <= 0 or listHeight <= 0 then
        return DEFAULT_TRANSMOG_PAGE_SIZE
    end

    local columns = math.max(1, math.floor(listWidth / width))
    local rows = math.max(1, math.floor(listHeight / height))
    return math.max(1, columns * rows)
end

local function setPreviewToRestore(slotName)
    local serverState = state.server[slotName]
    local previewState = state.preview[slotName]

    previewState.mode = "restore"
    previewState.itemId = nil
    previewState.effectiveId = serverState.realItemId
end

local function setPreviewToHidden(slotName)
    local previewState = state.preview[slotName]

    previewState.mode = "hidden"
    previewState.itemId = nil
    previewState.effectiveId = 0
end

local function setPreviewToItem(slotName, itemId)
    local previewState = state.preview[slotName]
    local serverState = state.server[slotName]

    itemId = tonumber(itemId)
    if not itemId or itemId <= 0 then
        return
    end

    if serverState.realItemId and itemId == serverState.realItemId then
        setPreviewToRestore(slotName)
        return
    end

    previewState.mode = "item"
    previewState.itemId = itemId
    previewState.effectiveId = itemId
end

local function refreshPreviewFromServer(slotName)
    copyServerToPreview(slotName)
    if state.currentSlot == slotName then
        local displayedItemId = getDisplayedItemIdForAppearance(slotName, state.preview[slotName].itemId, transmogTab.list.itemIds)
        transmogTab.list:SelectByItemId(displayedItemId or state.preview[slotName].itemId or -1)
    end
end

local function updatePreviewModel()
    if not transmogTab:IsShown() then
        return
    end

    local hasPreviewData = false
    for _, info in ipairs(SLOT_DATA) do
        if state.preview[info.name].effectiveId ~= nil then
            hasPreviewData = true
            break
        end
    end

    if not hasPreviewData and not state.synced then
        return
    end

    mainFrame.dressingRoom:SetUnit("player")
    mainFrame.dressingRoom:Undress()

    for _, info in ipairs(SLOT_DATA) do
        local itemId = state.preview[info.name].effectiveId
        if itemId and itemId > 0 then
            mainFrame.dressingRoom:TryOn(itemId)
        end
    end

    -- DressUpModel can visually favor another equipped weapon slot unless
    -- the currently browsed weapon slot is tried on again last.
    if WEAPON_SLOT[state.currentSlot] then
        local selectedItemId = state.preview[state.currentSlot].effectiveId
        if selectedItemId and selectedItemId > 0 then
            mainFrame.dressingRoom:TryOn(selectedItemId)
        end
    end

    if mainFrame.dressingRoom.shadowformEnabled then
        mainFrame.dressingRoom:EnableShadowform()
    end
end

local function saveDressingRoomView()
    local x, y, z = mainFrame.dressingRoom:GetPosition()

    state.previousView = {
        x = tonumber(x) or 0,
        y = tonumber(y) or 0,
        z = tonumber(z) or 0,
        facing = tonumber(mainFrame.dressingRoom:GetFacing()) or 0,
    }
end

local function setTransmogDressingRoomView()
    mainFrame.dressingRoom:SetPosition(0, 0, 0)
    mainFrame.dressingRoom:SetFacing(0)
end

local function restoreDressingRoomView()
    local view = state.previousView
    if not view then
        return
    end

    mainFrame.dressingRoom:SetPosition(view.x or 0, view.y or 0, view.z or 0)
    mainFrame.dressingRoom:SetFacing(view.facing or 0)
end

local function showListMessage(text)
    transmogTab.messageText:SetText(text or "")
    transmogTab.messageText:Show()
    transmogTab.list:Hide()

    for _, dressingRoom in ipairs(transmogTab.list.dressingRooms) do
        dressingRoom:OnUpdateModel(nil)
        dressingRoom:ClearModel()
        dressingRoom:Hide()
    end
end

local function updateStatusText()
    local slotName = state.currentSlot
    local dirtyCount = getDirtyCount()
    if not state.enabled then
        transmogTab.statusText:SetText(state.disabledReason or "Transmog is unavailable.")
        return
    end

    local searchSuffix = state.search ~= "" and ("  |  Filter: "..state.search) or ""
    transmogTab.statusText:SetText(("Slot: %s  |  Pending changes: %d%s"):format(slotName, dirtyCount, searchSuffix))
end

local function updateActionButtons()
    local hasDirty = getDirtyCount() > 0
    local currentDirty = isSlotDirty(state.currentSlot)
    local hasApplied = hasAppliedTransmogs()

    if not state.enabled then
        transmogTab.buttonApply:Disable()
        transmogTab.buttonRestore:Disable()
        transmogTab.buttonHide:Disable()
        transmogTab.buttonRevertAll:Disable()
        transmogTab.buttonApplyAll:Disable()
        transmogTab.buttonRevert:Disable()
        transmogTab.buttonPrev:Disable()
        transmogTab.buttonNext:Disable()
        return
    end

    if currentDirty then
        transmogTab.buttonApply:Enable()
    else
        transmogTab.buttonApply:Disable()
    end

    local serverState = state.server[state.currentSlot]
    local previewState = state.preview[state.currentSlot]

    if serverState.itemId ~= nil or previewState.mode ~= "restore" then
        transmogTab.buttonRestore:Enable()
    else
        transmogTab.buttonRestore:Disable()
    end

    if previewState.mode ~= "hidden" or serverState.itemId ~= 0 then
        transmogTab.buttonHide:Enable()
    else
        transmogTab.buttonHide:Disable()
    end

    if hasApplied and not state.applyingAppearanceSet then
        transmogTab.buttonRevertAll:Enable()
    else
        transmogTab.buttonRevertAll:Disable()
    end

    if hasDirty then
        transmogTab.buttonApplyAll:Enable()
        transmogTab.buttonRevert:Enable()
    else
        transmogTab.buttonApplyAll:Disable()
        transmogTab.buttonRevert:Disable()
    end

    if state.currentPage > 1 then
        transmogTab.buttonPrev:Enable()
    else
        transmogTab.buttonPrev:Disable()
    end

    if state.hasMorePages then
        transmogTab.buttonNext:Enable()
    else
        transmogTab.buttonNext:Disable()
    end
end

local refreshSlotButton

local pendingSlotButtonRefreshes = {}
local slotButtonRefreshFrame = CreateFrame("Frame")
local function slotButtonRefreshFrame_OnUpdate(self)
    self:SetScript("OnUpdate", nil)

    local queuedRefreshes = pendingSlotButtonRefreshes
    pendingSlotButtonRefreshes = {}

    for slotName, itemId in pairs(queuedRefreshes) do
        local previewState = state.preview[slotName]
        if previewState and previewState.effectiveId == itemId then
            refreshSlotButton(slotName)
        end
    end
end

local function queueSlotButtonRefresh(slotName, itemId)
    pendingSlotButtonRefreshes[slotName] = itemId
    if slotButtonRefreshFrame:GetScript("OnUpdate") == nil then
        slotButtonRefreshFrame:SetScript("OnUpdate", slotButtonRefreshFrame_OnUpdate)
    end
end

refreshSlotButton = function(slotName)
    local button = state.slotButtons[slotName]
    if not button then
        return
    end

    local previewState = state.preview[slotName]
    local itemId = previewState.effectiveId
    local itemLink
    local texture
    if itemId and itemId > 0 then
        local itemName
        local itemRarity
        local itemLevel
        local itemMinLevel
        local itemType
        local itemSubType
        local itemStackCount
        local itemEquipLoc
        itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, texture = GetItemInfo(itemId)
    end
    local icon = itemId and itemId > 0 and (GetItemIcon(itemId) or texture) or nil

    if itemId and itemId > 0 and not icon and not itemLink then
        ns.QueryItem(itemId, function(queriedItemId, success)
            if success and previewState.effectiveId == queriedItemId then
                queueSlotButtonRefresh(slotName, queriedItemId)
            end
        end)
    end

    if icon then
        SetItemButtonTexture(button, icon)
        button.defaultTexture:Hide()
        button.hiddenLabel:Hide()
    else
        SetItemButtonTexture(button, nil)
        button.defaultTexture:Show()
        if previewState.effectiveId == 0 then
            button.hiddenLabel:Show()
        else
            button.hiddenLabel:Hide()
        end
    end

    if isSlotDirty(slotName) then
        button.pendingGlow:Show()
    else
        button.pendingGlow:Hide()
    end
end

local function refreshAllSlotButtons()
    for _, info in ipairs(SLOT_DATA) do
        refreshSlotButton(info.name)
    end
end

local updatePageText

local function selectSlot(slotName)
    if not SLOT_ID_BY_NAME[slotName] then
        return
    end

    state.currentSlot = slotName
    if trim(transmogTab.searchBox:GetText()) == "" then
        state.currentPage = tonumber(state.slotPages[slotName]) or 1
        if state.currentPage < 1 then
            state.currentPage = 1
        end
    end

    for _, info in ipairs(SLOT_DATA) do
        local button = state.slotButtons[info.name]
        if button then
            if info.name == slotName then
                button:LockHighlight()
            else
                button:UnlockHighlight()
            end
        end
    end

    updatePageText()
    updateStatusText()
    updateActionButtons()
end

updatePageText = function()
    transmogTab.pageText:SetText(("Page %d"):format(state.currentPage))
end

local requestCurrentSlotItems
local requestCurrentSlotItemPage
local loadCurrentSlotItems
local requestUnobtainedSlotItems
local loadUnobtainedSlotItems
local requestItemSetCatalog
local rebuildSetLists
local updateSetPreview
local updateSetButtons

local function invalidateItemSetCatalog()
    state.itemSetCatalogLoaded = false
    state.itemSetCatalogDirty = true
    state.itemSetCatalogDirtyAt = GetTime and GetTime() or 0
end

local function canHandlePageNavigation()
    return state.enabled
        and state.viewMode == "items"
        and transmogTab:IsShown()
        and not transmogTab.searchBox:HasFocus()
end

local function changePage(direction)
    if not canHandlePageNavigation() then
        return false
    end

    direction = tonumber(direction)
    if direction == nil or direction == 0 then
        return false
    end

    if direction < 0 then
        if state.currentPage <= 1 then
            return false
        end

        state.currentPage = state.currentPage - 1
    else
        if not state.hasMorePages then
            return false
        end

        state.currentPage = state.currentPage + 1
    end

    PlaySound("gsTitleOptionOK")
    requestCurrentSlotItems(false)
    return true
end

local function handlePageScroll(_, delta)
    if delta == nil or delta == 0 then
        return false
    end

    if state.viewMode == "sets" and transmogTab:IsShown() and transmogTab.setsFrame:IsShown() then
        local scrollFrame = transmogTab.setsFrame.listScroll
        local scrollChild = transmogTab.setsFrame.list
        if not scrollFrame or not scrollChild then
            return false
        end

        local maxScroll = math.max(0, (scrollChild:GetHeight() or 0) - (scrollFrame:GetHeight() or 0))
        if maxScroll <= 0 then
            scrollFrame:SetVerticalScroll(0)
            return false
        end

        local currentScroll = scrollFrame:GetVerticalScroll() or 0
        local nextScroll = currentScroll - (delta * SETS_SCROLL_STEP)
        if nextScroll < 0 then
            nextScroll = 0
        elseif nextScroll > maxScroll then
            nextScroll = maxScroll
        end

        if nextScroll == currentScroll then
            return false
        end

        scrollFrame:SetVerticalScroll(nextScroll)
        return true
    end

    if delta > 0 then
        return changePage(-1)
    end

    return changePage(1)
end

local function updateListSelection()
    local previewState = state.preview[state.currentSlot]
    if previewState.mode == "item" and previewState.itemId then
        local displayedItemId = getDisplayedItemIdForAppearance(state.currentSlot, previewState.itemId, transmogTab.list.itemIds)
        transmogTab.list:SelectByItemId(displayedItemId or previewState.itemId)
    else
        transmogTab.list.selectedItemId = nil
        transmogTab.list.selectedItemIndex = nil
        for _, dressingRoom in ipairs(transmogTab.list.dressingRooms) do
            dressingRoom:SetBackdropBorderColor(1, 1, 1)
        end
    end
end

local function updateCandidateList(itemIds)
    itemIds = dedupeItemIdsByAppearance(state.currentSlot, itemIds or {})

    if #itemIds == 0 then
        local message = state.search ~= "" and "No unlocked appearances match this search." or "No unlocked appearances for this slot yet."
        showListMessage(message)
        updateListSelection()
        updateStatusText()
        updateActionButtons()
        return
    end

    local width, height, x, y, z, sequence, modelScale = getListPreviewSetup(state.currentSlot)

    transmogTab.messageText:Hide()
    transmogTab.list:Show()
    transmogTab.list:SetItems(itemIds)
    transmogTab.list:SetupModel(width, height, x, y, z, 0, sequence, modelScale)
    transmogTab.list:SetPage(1)

    -- For hand-weapon slots, skip Undress() inside queryItemHandler so the
    -- player's real equipped off-hand stays on the model and WoW doesn't
    -- auto-mirror a 1H weapon into both hand attachment points.
    transmogTab.list.skipUndress = (state.currentSlot == "Main Hand" or state.currentSlot == "Off-hand")

    transmogTab.list:Update()
    updateListSelection()
    updateStatusText()
    updateActionButtons()
end

requestCurrentSlotItems = function(resetPage)
    if not state.enabled then
        return
    end

    if resetPage then
        state.currentPage = 1
    end

    state.search = trim(transmogTab.searchBox:GetText())
    state.requestToken = state.requestToken + 1
    state.hasMorePages = false

    updatePageText()
    updateStatusText()
    showListMessage("Loading appearances...")
    updateActionButtons()

    local slotId = SLOT_ID_BY_NAME[state.currentSlot]
    local pageSize = getCurrentSlotPageSize(state.currentSlot)
    if state.search ~= "" then
        AIO.Handle("Transmog", "SetSearchCurrentSlotItemIds", slotId, state.currentPage, state.search, pageSize, state.requestToken)
    else
        AIO.Handle("Transmog", "SetCurrentSlotItemIds", slotId, state.currentPage, pageSize, state.requestToken)
    end
end

requestCurrentSlotItemPage = function(slotName, itemId)
    if not state.enabled then
        return
    end

    local slotId = SLOT_ID_BY_NAME[slotName]
    itemId = tonumber(itemId) or 0
    if not slotId or itemId <= 0 then
        state.currentPage = 1
        updatePageText()
        requestCurrentSlotItems(false)
        return
    end

    state.pageLookupToken = state.pageLookupToken + 1
    state.pageLookupSlot = slotName
    state.pageLookupAnchor = itemId
    state.currentPage = 1
    state.hasMorePages = false

    updatePageText()
    showListMessage("Locating current appearance...")
    updateActionButtons()

    AIO.Handle("Transmog", "SetCurrentSlotItemPage", slotId, itemId, getCurrentSlotPageSize(slotName), state.pageLookupToken)
end

loadCurrentSlotItems = function()
    if not state.enabled then
        return
    end

    local currentSearch = trim(transmogTab.searchBox:GetText())
    if currentSearch ~= "" then
        requestCurrentSlotItems(true)
        return
    end

    local slotName = state.currentSlot
    local currentAnchor = getCurrentSlotPageAnchor(slotName)
    local rememberedPage = tonumber(state.slotPages[slotName])
    local rememberedAnchor = tonumber(state.slotPageAnchors[slotName]) or 0

    if rememberedPage and rememberedPage > 0 and rememberedAnchor == currentAnchor then
        state.currentPage = rememberedPage
        updatePageText()
        requestCurrentSlotItems(false)
        return
    end

    if currentAnchor and currentAnchor > 0 then
        requestCurrentSlotItemPage(slotName, currentAnchor)
    else
        state.currentPage = rememberedPage and rememberedPage > 0 and rememberedPage or 1
        updatePageText()
        requestCurrentSlotItems(false)
    end
end

-- ---- Unobtained appearances (items in the DB the player has NOT yet unlocked) ----
--
-- The server-side handlers required are:
--   "SetUnobtainedSlotItemIds"       (slotId, page, pageSize, requestToken)
--   "SetSearchUnobtainedSlotItemIds" (slotId, page, search, pageSize, requestToken)
-- Each should return ALL transmog-eligible items for the slot minus the player's
-- unlocked set, paginated the same way as SetCurrentSlotItemIds.  The client
-- handler that receives the response is handlers.InitUnobtainedTab below.

requestUnobtainedSlotItems = function(resetPage)
    if not state.enabled then
        return
    end

    if resetPage then
        state.unobtainedPage = 1
    end

    state.unobtainedSearch = trim(transmogTab.searchBox:GetText())
    state.unobtainedRequestToken = state.unobtainedRequestToken + 1
    state.unobtainedHasMorePages = false

    updatePageText()
    showListMessage("Loading unobtained appearances...")
    updateActionButtons()

    local slotId = SLOT_ID_BY_NAME[state.currentSlot]
    local pageSize = getCurrentSlotPageSize(state.currentSlot)
    if state.unobtainedSearch ~= "" then
        AIO.Handle("Transmog", "SetSearchUnobtainedSlotItemIds", slotId, state.unobtainedPage, state.unobtainedSearch, pageSize, state.unobtainedRequestToken)
    else
        AIO.Handle("Transmog", "SetUnobtainedSlotItemIds", slotId, state.unobtainedPage, pageSize, state.unobtainedRequestToken)
    end
end

loadUnobtainedSlotItems = function()
    if not state.enabled then
        return
    end

    local currentSearch = trim(transmogTab.searchBox:GetText())
    if currentSearch ~= "" then
        requestUnobtainedSlotItems(true)
        return
    end

    local slotName = state.currentSlot
    local rememberedPage = tonumber(state.unobtainedSlotPages[slotName]) or 1
    state.unobtainedPage = math.max(1, rememberedPage)
    updatePageText()
    requestUnobtainedSlotItems(false)
end

requestItemSetCatalog = function()
    if not state.enabled or state.itemSetCatalogRequestPending then
        return
    end

    state.itemSetCatalogRequestPending = true
    state.itemSetCatalogRequestStartedAt = GetTime and GetTime() or 0
    updateSetButtons()

    if state.viewMode == "sets" and state.setSource == SET_SOURCE_CATALOG
        and #state.itemSetCatalog == 0 then
        transmogTab.setsFrame.previewTitle:SetText("Loading Item Sets")
        transmogTab.setsFrame.previewInfo:SetText("Fetching unlocked account item sets...")
    end

    AIO.Handle("Transmog", "GetUnlockedItemSets")
end

local function shouldRefreshItemSetCatalog(force)
    if not state.enabled or state.itemSetCatalogRequestPending then
        return false
    end

    if not force then
        if not transmogTab:IsShown() or state.viewMode ~= "sets" or state.setSource ~= SET_SOURCE_CATALOG then
            return false
        end
    end

    local now = GetTime and GetTime() or 0
    if force then
        return true
    end

    if not state.itemSetCatalogLoaded or #state.itemSetCatalog == 0 then
        return true
    end

    if state.itemSetCatalogDirty then
        if now <= 0 then
            return true
        end

        return (now - (state.itemSetCatalogDirtyAt or 0)) >= SETS_DIRTY_REFRESH_DELAY
    end

    if now <= 0 then
        return false
    end

    return (now - (state.itemSetCatalogLastRefreshAt or 0)) >= SETS_AUTO_REFRESH_INTERVAL
end

local function refreshItemSetCatalogIfNeeded(force)
    if not shouldRefreshItemSetCatalog(force) then
        return false
    end

    requestItemSetCatalog()
    return true
end

local function requestServerState()
    if not state.enabled then
        return
    end

    AIO.Handle("Transmog", "SetTransmogItemIds")
end

local lastBagContentsSignature = nil
local pendingBagScanDelay = 0
local pendingBagScanForce = false
local bagScanFrame = CreateFrame("Frame")

local function getContainerItemIdCompat(bagId, slotId)
    if type(GetContainerItemID) == "function" then
        local rawItemId = GetContainerItemID(bagId, slotId)
        local itemId = rawItemId and tonumber(rawItemId) or nil
        if itemId and itemId > 0 then
            return itemId
        end
    end

    local itemLink = type(GetContainerItemLink) == "function" and GetContainerItemLink(bagId, slotId) or nil
    if type(itemLink) ~= "string" then
        return nil
    end

    return tonumber(string.match(itemLink, "item:(%d+)"))
end

local function getBagContentsSignature()
    local entries = {}
    local maxBagId = tonumber(NUM_BAG_SLOTS) or 4

    for bagId = 0, maxBagId do
        local slotCount = type(GetContainerNumSlots) == "function" and tonumber(GetContainerNumSlots(bagId)) or 0
        if slotCount and slotCount > 0 then
            for slotId = 1, slotCount do
                local itemId = getContainerItemIdCompat(bagId, slotId)
                if itemId and itemId > 0 then
                    entries[#entries + 1] = bagId..":"..slotId..":"..itemId
                end
            end
        end
    end

    return table.concat(entries, "|")
end

local function refreshAppearanceStateFromInventory(force)
    if not state.enabled then
        return false
    end

    local signature = getBagContentsSignature()
    if not force and signature == lastBagContentsSignature then
        return false
    end

    lastBagContentsSignature = signature
    invalidateItemSetCatalog()
    AIO.Handle("Transmog", "ScanInventoryUnlocks")
    requestServerState()

    if state.viewMode == "sets" and state.setSource == SET_SOURCE_CATALOG then
        refreshItemSetCatalogIfNeeded(false)
    end

    return true
end

local function bagScanFrame_OnUpdate(self, elapsed)
    pendingBagScanDelay = math.max(0, pendingBagScanDelay - (elapsed or 0))
    if pendingBagScanDelay > 0 then
        return
    end

    self:SetScript("OnUpdate", nil)
    local force = pendingBagScanForce
    pendingBagScanForce = false
    refreshAppearanceStateFromInventory(force)
end

local function scheduleBagAppearanceScan(force, delay)
    pendingBagScanForce = pendingBagScanForce or force or false

    local requestedDelay = tonumber(delay) or 0
    if bagScanFrame:GetScript("OnUpdate") == nil then
        pendingBagScanDelay = requestedDelay
        bagScanFrame:SetScript("OnUpdate", bagScanFrame_OnUpdate)
    else
        pendingBagScanDelay = math.min(pendingBagScanDelay, requestedDelay)
    end
end

local function normalizeAppearanceSet(itemIds)
    local normalized = {}

    for index = 1, #SLOT_DATA do
        local slotName = SLOT_DATA[index] and SLOT_DATA[index].name or nil
        local itemId = type(itemIds) == "table" and tonumber(itemIds[index]) or nil
        if itemId and itemId > 0 then
            normalized[index] = math.floor(itemId)
        elseif itemId == 0 then
            normalized[index] = 0
        else
            normalized[index] = slotHasRestorableAppearance(slotName) and -1 or 0
        end
    end

    return normalized
end

local function applyAppearanceSetAsTransmog(itemIds)
    if not state.enabled then
        if state.disabledReason then
            SELECTED_CHAT_FRAME:AddMessage("|ccff6ff98<Appearance Buddy>|r: "..state.disabledReason)
        end
        return false
    end

    state.applyingAppearanceSet = true
    if transmogTab:IsShown() and state.viewMode == "sets" then
        updateSetButtons()
    end
    AIO.Handle("Transmog", "ApplyAppearanceSet", normalizeAppearanceSet(itemIds))
    return true
end

local function revertAllTransmogs()
    local restoreAll = {}
    for index, info in ipairs(SLOT_DATA) do
        restoreAll[index] = slotHasRestorableAppearance(info.name) and -1 or 0
    end

    return applyAppearanceSetAsTransmog(restoreAll)
end

local function applyUnlockedCatalogSet(itemSetId)
    itemSetId = tonumber(itemSetId)
    if not state.enabled or not itemSetId or itemSetId == 0 then
        return false
    end

    state.applyingUnlockedItemSet = true
    if transmogTab:IsShown() and state.viewMode == "sets" then
        updateSetButtons()
    end
    AIO.Handle("Transmog", "ApplyUnlockedItemSet", itemSetId)
    return true
end

local function commitSlot(slotName)
    if not state.enabled then
        return
    end

    local slotId = SLOT_ID_BY_NAME[slotName]
    local serverState = state.server[slotName]
    local previewState = state.preview[slotName]

    if previewState.mode == "restore" then
        -- Always send nil to mean "remove transmog override entirely".
        -- The old code sent 0 (= hide) when slotHasRestorableAppearance was
        -- false, which caused clicking Restore → Apply on a hidden slot to
        -- immediately re-hide it instead of clearing the transmog.
        AIO.Handle("Transmog", "EquipTransmogItem", nil, slotId)
        serverState.itemId = nil
        serverState.effectiveId = serverState.realItemId
    elseif previewState.mode == "hidden" then
        AIO.Handle("Transmog", "EquipTransmogItem", 0, slotId)
        serverState.itemId = 0
        serverState.effectiveId = 0
    elseif previewState.mode == "item" and previewState.itemId then
        AIO.Handle("Transmog", "EquipTransmogItem", previewState.itemId, slotId)
        serverState.itemId = previewState.itemId
        serverState.effectiveId = previewState.itemId
    end

    copyServerToPreview(slotName)
    refreshSlotButton(slotName)
end

local function revertAllPreview()
    copyAllServerToPreview()
    refreshAllSlotButtons()
    updatePreviewModel()
    updateListSelection()
    updateStatusText()
    updateActionButtons()
end

local function onSlotButtonEnter(self)
    local slotName = self.slotName
    local serverState = state.server[slotName]
    local previewState = state.preview[slotName]

    GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
    GameTooltip:ClearLines()
    GameTooltip:AddLine(slotName)

    if serverState.realItemId then
        GameTooltip:AddLine("Original: "..(safeLink(serverState.realItemId) or ("item:"..serverState.realItemId)), 1, 1, 1)
    else
        GameTooltip:AddLine("Original: no item equipped", 0.75, 0.75, 0.75)
    end

    if serverState.itemId == 0 then
        GameTooltip:AddLine("Applied: hidden", 1, 0.3, 0.3)
    elseif serverState.itemId and serverState.itemId > 0 then
        GameTooltip:AddLine("Applied: "..(safeLink(serverState.itemId) or ("item:"..serverState.itemId)), 0.3, 1, 0.3)
    else
        GameTooltip:AddLine("Applied: original appearance", 0.3, 1, 0.3)
    end

    if isSlotDirty(slotName) then
        if previewState.mode == "hidden" then
            GameTooltip:AddLine("Preview: hidden", 1, 0.82, 0)
        elseif previewState.mode == "restore" then
            GameTooltip:AddLine("Preview: restore original appearance", 1, 0.82, 0)
        elseif previewState.itemId then
            GameTooltip:AddLine("Preview: "..(safeLink(previewState.itemId) or ("item:"..previewState.itemId)), 1, 0.82, 0)
        end
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Click to browse unlocked appearances.")
    GameTooltip:Show()
end

local function onSlotButtonLeave()
    GameTooltip:Hide()
end

local function onSlotButtonClick(self)
    PlaySound("gsTitleOptionOK")
    selectSlot(self.slotName)
    loadCurrentSlotItems()
end

local function onListItemEnter(self)
    local itemId = self:GetParent().itemId
    if not itemId then
        return
    end

    GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
    GameTooltip:ClearLines()
    local link = safeLink(itemId)
    if link then
        GameTooltip:SetHyperlink(link)
    else
        GameTooltip:AddLine("item:"..itemId)
    end

    if GetSettings and GetSettings().showShortcutsInTooltip then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cff00ff00Left Click:|r preview this appearance.")
        GameTooltip:AddLine("|cff00ff00Shift + Left Click:|r create an item link.")
        GameTooltip:AddLine("|cff00ff00Ctrl + Left Click:|r create a Wowhead URL.")
    end
    GameTooltip:Show()
end

local function onListItemLeave()
    GameTooltip:Hide()
end

local function onListItemClick(self)
    local itemId = self:GetParent().itemId
    if not itemId then
        return
    end

    if IsShiftKeyDown() then
        local link = safeLink(itemId)
        if link then
            SELECTED_CHAT_FRAME:AddMessage("|ccff6ff98<Appearance Buddy>|r: "..link.." ("..itemId..")")
        end
        return
    end

    if IsControlKeyDown() then
        ns.ShowWowheadURLDialog(itemId)
        return
    end

    PlaySound("gsTitleOptionOK")

    setPreviewToItem(state.currentSlot, itemId)
    refreshSlotButton(state.currentSlot)
    updatePreviewModel()
    updateStatusText()
    updateActionButtons()
    onListItemEnter(self)
end

-- Transmog slot buttons live on the dressing room (same positions as main slots).
-- They are children of transmogTab so they auto-show/hide with the tab.
for index, info in ipairs(SLOT_DATA) do
    local safeSlotName = info.name:gsub("[%s%-]", "")
    local button = CreateFrame("Button", (transmogTab:GetName() or addon.."Transmog").."Slot"..safeSlotName, transmogTab, "ItemButtonTemplate")
    button:SetFrameLevel(mainFrame.dressingRoom:GetFrameLevel() + 1)
    button:RegisterForClicks("LeftButtonUp")
    button.slotName = info.name
    button:SetScript("OnClick", onSlotButtonClick)
    button:SetScript("OnEnter", onSlotButtonEnter)
    button:SetScript("OnLeave", onSlotButtonLeave)

    button.defaultTexture = button:CreateTexture(nil, "BACKGROUND")
    button.defaultTexture:SetAllPoints()
    button.defaultTexture:SetTexture(mainFrame.slots[info.name].textures.empty:GetTexture())

    button.pendingGlow = button:CreateTexture(nil, "OVERLAY")
    button.pendingGlow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    button.pendingGlow:SetBlendMode("ADD")
    button.pendingGlow:SetPoint("CENTER", 0, 0)
    button.pendingGlow:SetWidth(48)
    button.pendingGlow:SetHeight(48)
    button.pendingGlow:SetVertexColor(1, 0.82, 0)
    button.pendingGlow:Hide()

    button.hiddenLabel = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.hiddenLabel:SetPoint("CENTER", 0, 0)
    button.hiddenLabel:SetText("X")
    button.hiddenLabel:SetTextColor(1, 0.25, 0.25)
    button.hiddenLabel:Hide()

    state.slotButtons[info.name] = button
end

-- Position transmog slot buttons on the dressing room, mirroring main slot layout.
do
    local dr = mainFrame.dressingRoom
    local sb = state.slotButtons
    sb["Head"]:SetPoint("TOPLEFT", dr, "TOPLEFT", 16, -16)
    sb["Shoulder"]:SetPoint("TOP", sb["Head"], "BOTTOM", 0, -4)
    sb["Back"]:SetPoint("TOP", sb["Shoulder"], "BOTTOM", 0, -4)
    sb["Chest"]:SetPoint("TOP", sb["Back"], "BOTTOM", 0, -4)
    sb["Shirt"]:SetPoint("TOP", sb["Chest"], "BOTTOM", 0, -36)
    sb["Tabard"]:SetPoint("TOP", sb["Shirt"], "BOTTOM", 0, -4)
    sb["Wrist"]:SetPoint("TOP", sb["Tabard"], "BOTTOM", 0, -36)
    sb["Hands"]:SetPoint("TOPRIGHT", dr, "TOPRIGHT", -16, -16)
    sb["Waist"]:SetPoint("TOP", sb["Hands"], "BOTTOM", 0, -4)
    sb["Legs"]:SetPoint("TOP", sb["Waist"], "BOTTOM", 0, -4)
    sb["Feet"]:SetPoint("TOP", sb["Legs"], "BOTTOM", 0, -4)
    sb["Off-hand"]:SetPoint("BOTTOM", dr, "BOTTOM", 0, 16)
    sb["Main Hand"]:SetPoint("RIGHT", sb["Off-hand"], "LEFT", -4, 0)
    sb["Ranged"]:SetPoint("LEFT", sb["Off-hand"], "RIGHT", 4, 0)
end

transmogTab.searchLabel = transmogTab:CreateFontString(nil, "OVERLAY", "GameFontNormal")
transmogTab.searchLabel:SetPoint("TOPLEFT", 8, -8)
transmogTab.searchLabel:SetText("Search")

transmogTab.searchBox = CreateFrame("EditBox", (transmogTab:GetName() or addon.."Transmog").."SearchBox", transmogTab, "InputBoxTemplate")
transmogTab.searchBox:SetPoint("LEFT", transmogTab.searchLabel, "RIGHT", 8, 0)
transmogTab.searchBox:SetWidth(180)
transmogTab.searchBox:SetHeight(20)
transmogTab.searchBox:SetAutoFocus(false)
transmogTab.searchBox:SetTextInsets(6, 6, 0, 0)
transmogTab.searchBox:SetScript("OnEscapePressed", function(self)
    self:ClearFocus()
end)
transmogTab.searchBox:SetScript("OnEnterPressed", function(self)
    self:ClearFocus()
    requestCurrentSlotItems(true)
end)

transmogTab.searchPlaceholder = transmogTab.searchBox:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
transmogTab.searchPlaceholder:SetPoint("LEFT", 6, 0)
transmogTab.searchPlaceholder:SetText("Item name or display id")

transmogTab.searchBox:SetScript("OnTextChanged", function(self)
    if self:GetText() == "" then
        transmogTab.searchPlaceholder:Show()
    else
        transmogTab.searchPlaceholder:Hide()
    end
end)

transmogTab.buttonSearch = CreateFrame("Button", transmogTabName.."ButtonSearch", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonSearch:SetPoint("LEFT", transmogTab.searchBox, "RIGHT", 8, 0)
transmogTab.buttonSearch:SetSize(70, 20)
transmogTab.buttonSearch:SetText("Search")
transmogTab.buttonSearch:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    requestCurrentSlotItems(true)
end)

transmogTab.buttonClearSearch = CreateFrame("Button", transmogTabName.."ButtonClearSearch", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonClearSearch:SetPoint("LEFT", transmogTab.buttonSearch, "RIGHT", 4, 0)
transmogTab.buttonClearSearch:SetSize(70, 20)
transmogTab.buttonClearSearch:SetText("Clear")
transmogTab.buttonClearSearch:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    transmogTab.searchBox:SetText("")
    loadCurrentSlotItems()
end)

transmogTab.buttonNext = CreateFrame("Button", transmogTabName.."ButtonNext", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonNext:SetPoint("TOPRIGHT", transmogTab, "TOPRIGHT", -6, -36)
transmogTab.buttonNext:SetSize(64, 20)
transmogTab.buttonNext:SetText("Next")
transmogTab.buttonNext:SetScript("OnClick", function()
    changePage(1)
end)

transmogTab.pageText = transmogTab:CreateFontString(nil, "OVERLAY", "GameFontNormal")
transmogTab.pageText:SetPoint("CENTER", transmogTab, "TOP", 0, -46)
transmogTab.pageText:SetText("Page 1")

transmogTab.buttonPrev = CreateFrame("Button", transmogTabName.."ButtonPrev", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonPrev:SetPoint("TOPLEFT", transmogTab, "TOPLEFT", 6, -36)
transmogTab.buttonPrev:SetSize(64, 20)
transmogTab.buttonPrev:SetText("Prev")
transmogTab.buttonPrev:SetScript("OnClick", function()
    changePage(-1)
end)

transmogTab.list = ns.CreatePreviewList(transmogTab)
transmogTab.list:SetPoint("TOPLEFT", 8, LIST_TOP_Y)
transmogTab.list:SetPoint("BOTTOMRIGHT", -8, LIST_BOTTOM_Y)
transmogTab.list:Hide()
transmogTab.list.onEnter = onListItemEnter
transmogTab.list.onLeave = onListItemLeave
transmogTab.list.onItemClick = onListItemClick

transmogTab.messageText = transmogTab:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
transmogTab.messageText:SetPoint("TOPLEFT", transmogTab.list, "TOPLEFT", 20, -24)
transmogTab.messageText:SetPoint("BOTTOMRIGHT", transmogTab.list, "BOTTOMRIGHT", -20, 24)
transmogTab.messageText:SetJustifyH("CENTER")
transmogTab.messageText:SetJustifyV("MIDDLE")
transmogTab.messageText:SetTextColor(1, 0.82, 0)
transmogTab.messageText:Hide()

transmogTab.statusText = transmogTab:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
transmogTab.statusText:SetPoint("BOTTOMLEFT", 12, STATUS_ROW_Y)
transmogTab.statusText:SetPoint("BOTTOMRIGHT", -12, STATUS_ROW_Y)
transmogTab.statusText:SetJustifyH("LEFT")

transmogTab.buttonApply = CreateFrame("Button", transmogTabName.."ButtonApply", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonApply:SetPoint("BOTTOMLEFT", 8, ACTION_ROW_Y)
transmogTab.buttonApply:SetSize(90, 22)
transmogTab.buttonApply:SetText("Apply")
transmogTab.buttonApply:SetScript("OnClick", function()
    if not isSlotDirty(state.currentSlot) then
        return
    end

    PlaySound("gsTitleOptionOK")
    commitSlot(state.currentSlot)
    requestServerState()
    updatePreviewModel()
    updateStatusText()
    updateActionButtons()
end)

transmogTab.buttonHide = CreateFrame("Button", transmogTabName.."ButtonHide", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonHide:SetPoint("LEFT", transmogTab.buttonApply, "RIGHT", 6, 0)
transmogTab.buttonHide:SetSize(90, 22)
transmogTab.buttonHide:SetText("Hide")
transmogTab.buttonHide:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    setPreviewToHidden(state.currentSlot)
    refreshSlotButton(state.currentSlot)
    updatePreviewModel()
    updateListSelection()
    updateStatusText()
    updateActionButtons()
end)

transmogTab.buttonRestore = CreateFrame("Button", transmogTabName.."ButtonRestore", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonRestore:SetPoint("LEFT", transmogTab.buttonHide, "RIGHT", 6, 0)
transmogTab.buttonRestore:SetSize(90, 22)
transmogTab.buttonRestore:SetText("Restore")
transmogTab.buttonRestore:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    setPreviewToRestore(state.currentSlot)
    refreshSlotButton(state.currentSlot)
    updatePreviewModel()
    updateListSelection()
    updateStatusText()
    updateActionButtons()
end)

transmogTab.buttonRevert = CreateFrame("Button", transmogTabName.."ButtonRevert", mainFrame, "UIPanelButtonTemplate2")
transmogTab.buttonRevert:Hide()
transmogTab.buttonRevert:SetSize(140, 22)
transmogTab.buttonRevert:SetText("Revert Preview")
transmogTab.buttonRevert:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    revertAllPreview()
end)

transmogTab.buttonRevertAll = CreateFrame("Button", transmogTabName.."ButtonRevertAll", mainFrame, "UIPanelButtonTemplate2")
transmogTab.buttonRevertAll:Hide()
transmogTab.buttonRevertAll:SetSize(130, 22)
transmogTab.buttonRevertAll:SetText("Revert All")
transmogTab.buttonRevertAll:SetScript("OnClick", function()
    if not hasAppliedTransmogs() then
        return
    end

    PlaySound("gsTitleOptionOK")
    revertAllTransmogs()
    updateActionButtons()
end)

transmogTab.buttonApplyAll = CreateFrame("Button", transmogTabName.."ButtonApplyAll", mainFrame, "UIPanelButtonTemplate2")
transmogTab.buttonApplyAll:Hide()
transmogTab.buttonApplyAll:SetSize(130, 22)
transmogTab.buttonApplyAll:SetText("Apply All")
transmogTab.buttonApplyAll:SetScript("OnClick", function()
    if getDirtyCount() == 0 then
        return
    end

    PlaySound("gsTitleOptionOK")
    for _, info in ipairs(SLOT_DATA) do
        if isSlotDirty(info.name) then
            commitSlot(info.name)
        end
    end

    requestServerState()
    refreshAllSlotButtons()
    updatePreviewModel()
    updateStatusText()
    updateActionButtons()
end)

-- Position the 3 global transmog action buttons under the dressing room
-- (main Use Target/Undress/Reset/Send buttons are hidden while transmog tab is open).
do
    local dr = mainFrame.dressingRoom
    transmogTab.buttonRevertAll:SetPoint("TOPLEFT", dr, "BOTTOMLEFT", 0, 0)
    transmogTab.buttonRevert:SetPoint("LEFT", transmogTab.buttonRevertAll, "RIGHT", 0, 0)
    transmogTab.buttonApplyAll:SetPoint("TOPRIGHT", dr, "BOTTOMRIGHT", 0, 0)
end

transmogTab.buttonModeItems = CreateFrame("Button", transmogTabName.."ButtonModeItems", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonModeItems:SetPoint("TOPRIGHT", transmogTab, "TOPRIGHT", -6, -8)
transmogTab.buttonModeItems:SetSize(64, 20)
transmogTab.buttonModeItems:SetText("Items")

transmogTab.buttonModeSets = CreateFrame("Button", transmogTabName.."ButtonModeSets", transmogTab, "UIPanelButtonTemplate2")
transmogTab.buttonModeSets:SetPoint("RIGHT", transmogTab.buttonModeItems, "LEFT", -6, 0)
transmogTab.buttonModeSets:SetSize(64, 20)
transmogTab.buttonModeSets:SetText("Sets")



transmogTab.setsFrame = CreateFrame("Frame", transmogTabName.."SetsFrame", transmogTab)
transmogTab.setsFrame:SetPoint("TOPLEFT", 8, -34)
transmogTab.setsFrame:SetPoint("BOTTOMRIGHT", -8, SETS_FRAME_BOTTOM_Y)
transmogTab.setsFrame:Hide()

do
    local setsFrame = transmogTab.setsFrame
    local previewBackdrop = {
        bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    }

    setsFrame.buttonSourceSaved = CreateFrame("Button", transmogTabName.."ButtonSourceSaved", setsFrame, "UIPanelButtonTemplate2")
    setsFrame.buttonSourceSaved:SetPoint("TOPLEFT", 0, 0)
    setsFrame.buttonSourceSaved:SetSize(84, 20)
    setsFrame.buttonSourceSaved:SetText("Saved")

    setsFrame.buttonSourceCatalog = CreateFrame("Button", transmogTabName.."ButtonSourceCatalog", setsFrame, "UIPanelButtonTemplate2")
    setsFrame.buttonSourceCatalog:SetPoint("LEFT", setsFrame.buttonSourceSaved, "RIGHT", 6, 0)
    setsFrame.buttonSourceCatalog:SetSize(84, 20)
    setsFrame.buttonSourceCatalog:SetText("Catalog")

    setsFrame.listTitle = setsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    setsFrame.listTitle:SetPoint("TOPLEFT", 0, -28)
    setsFrame.listTitle:SetText("Saved Transmog Sets")

    setsFrame.listScroll = CreateFrame("ScrollFrame", transmogTabName.."SetsScroll", setsFrame, "UIPanelScrollFrameTemplate")
    setsFrame.listScroll:SetPoint("TOPLEFT", 0, -48)
    setsFrame.listScroll:SetPoint("BOTTOMLEFT", 0, 36)
    setsFrame.listScroll:SetWidth(SETS_LIST_SCROLL_WIDTH)

    setsFrame.list = ns.CreateListFrame(transmogTabName.."SetsList", nil, setsFrame.listScroll)
    setsFrame.list:SetPoint("TOPLEFT", 0, 0)
    setsFrame.list:SetWidth(SETS_LIST_WIDTH)
    setsFrame.listScroll:SetScrollChild(setsFrame.list)
    if ns.RefreshManagedScrollFrame then
        ns.RefreshManagedScrollFrame(setsFrame.listScroll)
    end
    setsFrame:HookScript("OnShow", function(self)
        if ns.RefreshManagedScrollFrame then
            ns.RefreshManagedScrollFrame(self.listScroll)
        end
    end)
    setsFrame:HookScript("OnHide", function(self)
        if ns.RefreshManagedScrollFrame then
            ns.RefreshManagedScrollFrame(self.listScroll, false)
        end
    end)

    setsFrame.previewTitle = setsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    setsFrame.previewTitle:SetPoint("TOPLEFT", SETS_PREVIEW_LEFT_X, -4)
    setsFrame.previewTitle:SetPoint("TOPRIGHT", -8, -4)
    setsFrame.previewTitle:SetJustifyH("LEFT")
    setsFrame.previewTitle:SetText("Set Preview")

    setsFrame.previewInfo = setsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    setsFrame.previewInfo:SetPoint("BOTTOMLEFT", SETS_PREVIEW_LEFT_X, 52)
    setsFrame.previewInfo:SetPoint("BOTTOMRIGHT", -8, 52)
    setsFrame.previewInfo:SetJustifyH("LEFT")
    setsFrame.previewInfo:SetJustifyV("TOP")

    setsFrame.previewModel = ns.CreateDressingRoom(nil, setsFrame)
    setsFrame.previewModel:SetPoint("TOPLEFT", SETS_PREVIEW_LEFT_X, -24)
    setsFrame.previewModel:SetPoint("BOTTOMRIGHT", -8, 84)
    setsFrame.previewModel:SetBackdrop(previewBackdrop)
    setsFrame.previewModel:SetBackdropColor(0.08, 0.08, 0.08, 1)
    setsFrame.previewModel:SetBackdropBorderColor(0.25, 0.25, 0.25)
    setsFrame.previewModel:SetUnit("player")
    setsFrame.previewModel:Reset()
    setsFrame.previewModel:SetScript("OnUpdate", function(self)
        local mainDR = ns.mainFrame and ns.mainFrame.dressingRoom
        if not mainDR then return end
        self:SetFacing(mainDR:GetFacing())
    end)
    updateSetPreviewBackground()

    setsFrame.buttonCopyCurrent = CreateFrame("Button", transmogTabName.."ButtonCopyCurrentSet", setsFrame, "UIPanelButtonTemplate2")
    setsFrame.buttonCopyCurrent:SetPoint("BOTTOMLEFT", 0, 0)
    setsFrame.buttonCopyCurrent:SetSize(116, 22)
    setsFrame.buttonCopyCurrent:SetText("Copy Current...")

    setsFrame.buttonRemoveSaved = CreateFrame("Button", transmogTabName.."ButtonRemoveSavedSet", setsFrame, "UIPanelButtonTemplate2")
    setsFrame.buttonRemoveSaved:SetPoint("LEFT", setsFrame.buttonCopyCurrent, "RIGHT", 6, 0)
    setsFrame.buttonRemoveSaved:SetSize(78, 22)
    setsFrame.buttonRemoveSaved:SetText("Remove")

    setsFrame.buttonRefreshCatalog = CreateFrame("Button", transmogTabName.."ButtonRefreshCatalog", setsFrame, "UIPanelButtonTemplate2")
    setsFrame.buttonRefreshCatalog:SetPoint("BOTTOMLEFT", 0, 0)
    setsFrame.buttonRefreshCatalog:SetSize(116, 22)
    setsFrame.buttonRefreshCatalog:SetText("Refresh")

    setsFrame.buttonApplySelected = CreateFrame("Button", transmogTabName.."ButtonApplySelectedSet", setsFrame, "UIPanelButtonTemplate2")
    setsFrame.buttonApplySelected:SetPoint("BOTTOMRIGHT", -8, 0)
    setsFrame.buttonApplySelected:SetSize(118, 22)
    setsFrame.buttonApplySelected:SetText("Apply Set")
end

local itemModeWidgets = {
    transmogTab.searchLabel,
    transmogTab.searchBox,
    transmogTab.searchPlaceholder,
    transmogTab.buttonSearch,
    transmogTab.buttonClearSearch,
    transmogTab.pageText,
    transmogTab.buttonPrev,
    transmogTab.buttonNext,
    transmogTab.list,
    transmogTab.messageText,
    transmogTab.statusText,
    transmogTab.buttonApply,
    transmogTab.buttonHide,
    transmogTab.buttonRestore,
    transmogTab.buttonRevert,
    transmogTab.buttonRevertAll,
    transmogTab.buttonApplyAll,
}

for _, info in ipairs(SLOT_DATA) do
    table.insert(itemModeWidgets, state.slotButtons[info.name])
end

local function updateModeButtons()
    transmogTab.buttonModeItems:UnlockHighlight()
    transmogTab.buttonModeSets:UnlockHighlight()
    if state.viewMode == "items" then
        transmogTab.buttonModeItems:LockHighlight()
    elseif state.viewMode == "sets" then
        transmogTab.buttonModeSets:LockHighlight()
    end
end

local function setItemModeVisible(visible)
    for _, widget in ipairs(itemModeWidgets) do
        if widget and widget ~= transmogTab.list and widget ~= transmogTab.messageText then
            if visible then
                widget:Show()
            else
                widget:Hide()
            end
        end
    end

    if visible then
        if transmogTab.messageText:GetText() ~= "" and (#transmogTab.list.itemIds == 0 or not transmogTab.list.dressingRoomSetup) then
            transmogTab.messageText:Show()
            transmogTab.list:Hide()
        else
            transmogTab.messageText:Hide()
            transmogTab.list:Show()
        end
    else
        transmogTab.messageText:Hide()
        transmogTab.list:Hide()
    end
end

local function getSelectedSavedSet()
    local selectedName = state.selectedSavedSetName
    if not selectedName then
        return nil
    end

    for _, setData in ipairs(getSavedTransmogSets()) do
        if setData.name == selectedName then
            return setData
        end
    end

    return nil
end

local function getSelectedCatalogSet()
    local selectedId = tonumber(state.selectedCatalogSetId)
    if not selectedId then
        return nil
    end

    for _, setData in ipairs(state.itemSetCatalog) do
        if tonumber(setData.id) == selectedId then
            return setData
        end
    end

    return nil
end

local function isCatalogSetComplete(setData)
    if type(setData) ~= "table" then
        return false
    end

    if setData.hasExactTotal == false then
        return false
    end

    local unlockedCount = tonumber(setData.unlockedCount) or 0
    local totalCount = tonumber(setData.totalCount) or 0
    return totalCount > 0 and unlockedCount >= totalCount
end

local function getCatalogSetRowLabel(setData)
    if type(setData) ~= "table" then
        return "Set"
    end

    local baseLabel = tostring(setData.displayName or setData.name or "Set")
    if isCatalogSetComplete(setData) then
        return "|cff40ff40"..baseLabel.."|r"
    end

    return baseLabel
end

local CATALOG_SLOT_LABELS = {
    ["Head"] = "Head",
    ["Shoulder"] = "Shoulders",
    ["Back"] = "Cloak",
    ["Chest"] = "Chest",
    ["Shirt"] = "Shirt",
    ["Tabard"] = "Tabard",
    ["Wrist"] = "Bracers",
    ["Hands"] = "Gloves",
    ["Waist"] = "Belt",
    ["Legs"] = "Legs",
    ["Feet"] = "Boots",
    ["Main Hand"] = "Main Hand",
    ["Off-hand"] = "Off-hand",
    ["Ranged"] = "Ranged",
}

local function getCatalogSetMissingSlots(setData)
    if type(setData) ~= "table" then
        return {}
    end

    local missing = {}
    for index, slotInfo in ipairs(SLOT_DATA) do
        local fullItemId = type(setData.fullItems) == "table" and tonumber(setData.fullItems[index]) or 0
        local unlockedItemId = type(setData.unlockedItems) == "table" and tonumber(setData.unlockedItems[index]) or 0

        if fullItemId > 0 and unlockedItemId <= 0 then
            missing[#missing + 1] = CATALOG_SLOT_LABELS[slotInfo.name] or slotInfo.name
        end
    end

    return missing
end

local function renderSetPreviewModelItems(model, itemIds)
    updateSetPreviewBackground()
    model:Reset()
    model:Undress()

    local retryItems = {}
    for index = 1, #SLOT_DATA do
        local itemId = type(itemIds) == "table" and tonumber(itemIds[index]) or nil
        if itemId and itemId > 0 then
            model:TryOn(itemId)
            retryItems[SLOT_DATA[index].name] = itemId
        end
    end

    for _, slotName in ipairs(SET_PREVIEW_RETRY_SLOT_ORDER) do
        local itemId = retryItems[slotName]
        if itemId and itemId > 0 then
            model:TryOn(itemId)
        end
    end

    if model.shadowformEnabled then
        model:EnableShadowform()
    end
end

local function setPreviewModelItems(model, itemIds)
    model.setPreviewToken = (model.setPreviewToken or 0) + 1
    local token = model.setPreviewToken
    local normalizedItems = {}
    local hasPendingQueries = false

    for index = 1, #SLOT_DATA do
        local itemId = type(itemIds) == "table" and tonumber(itemIds[index]) or 0
        if itemId and itemId > 0 then
            normalizedItems[index] = itemId
            local _, itemLink = GetItemInfo(itemId)
            if not itemLink then
                hasPendingQueries = true
                ns.QueryItem(itemId, function(queriedItemId, success)
                    if not success or not model or model.setPreviewToken ~= token or queriedItemId ~= itemId then
                        return
                    end

                    renderSetPreviewModelItems(model, normalizedItems)
                end)
            end
        else
            normalizedItems[index] = 0
        end
    end

    renderSetPreviewModelItems(model, normalizedItems)

    if hasPendingQueries and model.setPreviewToken == token then
        model:Show()
    end
end

updateSetButtons = function()
    local setsFrame = transmogTab.setsFrame
    local hasSelection = false
    local applyLocked = state.applyingAppearanceSet or state.applyingUnlockedItemSet or state.itemSetCatalogRequestPending

    if state.setSource == SET_SOURCE_SAVED then
        hasSelection = getSelectedSavedSet() ~= nil
        setsFrame.listTitle:SetText("Saved Transmog Sets")
        setsFrame.buttonSourceSaved:LockHighlight()
        setsFrame.buttonSourceCatalog:UnlockHighlight()
        setsFrame.buttonCopyCurrent:Show()
        setsFrame.buttonRefreshCatalog:Hide()
        setsFrame.buttonRemoveSaved:Show()
        setsFrame.buttonApplySelected:SetText("Apply Set")
        if hasSelection then
            setsFrame.buttonRemoveSaved:Enable()
        else
            setsFrame.buttonRemoveSaved:Disable()
        end
        if state.synced then
            setsFrame.buttonCopyCurrent:Enable()
        else
            setsFrame.buttonCopyCurrent:Disable()
        end
    else
        hasSelection = getSelectedCatalogSet() ~= nil
        setsFrame.listTitle:SetText("Unlocked Item Sets")
        setsFrame.buttonSourceSaved:UnlockHighlight()
        setsFrame.buttonSourceCatalog:LockHighlight()
        setsFrame.buttonCopyCurrent:Hide()
        setsFrame.buttonRemoveSaved:Hide()
        setsFrame.buttonRefreshCatalog:Show()
        if state.enabled and not state.itemSetCatalogRequestPending then
            setsFrame.buttonRefreshCatalog:Enable()
        else
            setsFrame.buttonRefreshCatalog:Disable()
        end
        setsFrame.buttonApplySelected:SetText("Apply Unlocked")
    end

    if state.enabled and hasSelection and not applyLocked then
        setsFrame.buttonApplySelected:Enable()
    else
        setsFrame.buttonApplySelected:Disable()
    end
end

updateSetPreview = function()
    local setsFrame = transmogTab.setsFrame
    updateSetPreviewBackground()

    if state.setSource == SET_SOURCE_SAVED then
        local savedSet = getSelectedSavedSet()
        if not savedSet then
            setsFrame.previewTitle:SetText("Set Preview")
            setsFrame.previewInfo:SetText("Select a saved transmog set or copy the current preview into a new named set.")
            setsFrame.previewModel.setPreviewToken = (setsFrame.previewModel.setPreviewToken or 0) + 1
            setsFrame.previewModel:Undress()
            return
        end

        local itemCount = 0
        local hiddenCount = 0
        local restoreCount = 0
        for index = 1, #SLOT_DATA do
            local value = tonumber(savedSet.items and savedSet.items[index]) or -1
            if value > 0 then
                itemCount = itemCount + 1
            elseif value == 0 then
                hiddenCount = hiddenCount + 1
            else
                restoreCount = restoreCount + 1
            end
        end

        setPreviewModelItems(setsFrame.previewModel, buildPreviewItemsFromTransmogSet(savedSet.items))
        setsFrame.previewTitle:SetText(savedSet.name)
        setsFrame.previewInfo:SetText(("Saved transmog set\nCustom appearances: %d  |  Hidden: %d  |  Restore: %d"):format(itemCount, hiddenCount, restoreCount))
    else
        local catalogSet = getSelectedCatalogSet()
        if not catalogSet then
            setsFrame.previewTitle:SetText("Set Preview")
            if state.itemSetCatalogRequestPending then
                setsFrame.previewInfo:SetText("Fetching unlocked item sets...")
            elseif not state.itemSetCatalogLoaded or #state.itemSetCatalog == 0 then
                setsFrame.previewInfo:SetText("Automatic catalog scanning is disabled.\nClick Refresh to load unlocked item sets.")
            else
                setsFrame.previewInfo:SetText("Select an unlocked item set to preview the full look. Applying it will use only the pieces your account has unlocked.")
            end
            setsFrame.previewModel.setPreviewToken = (setsFrame.previewModel.setPreviewToken or 0) + 1
            setsFrame.previewModel:Undress()
            return
        end

        setPreviewModelItems(setsFrame.previewModel, catalogSet.fullItems)
        setsFrame.previewTitle:SetText(catalogSet.name or "Unlocked Item Set")
        local infoLines = {
            ("Unlocked pieces: %d/%d"):format(tonumber(catalogSet.unlockedCount) or 0, tonumber(catalogSet.totalCount) or 0)
        }
        local missingSlots = getCatalogSetMissingSlots(catalogSet)
        if #missingSlots > 0 then
            infoLines[#infoLines + 1] = "Missing: "..table.concat(missingSlots, ", ")
        end
        infoLines[#infoLines + 1] = "Preview hides non-set slots. Apply uses only unlocked appearances."
        setsFrame.previewInfo:SetText(table.concat(infoLines, "\n"))
    end
end

rebuildSetLists = function()
    local setsFrame = transmogTab.setsFrame
    local listFrame = setsFrame.list
    local reselectValue = state.setSource == SET_SOURCE_SAVED and state.selectedSavedSetName or state.selectedCatalogSetId

    listFrame:Clear()

    if state.setSource == SET_SOURCE_SAVED then
        sortSavedTransmogSets()
        for _, setData in ipairs(getSavedTransmogSets()) do
            local buttonId = listFrame:AddItem(setData.name)
            local button = listFrame:GetButton(buttonId)
            button.setName = setData.name
            button.fullLabelText = setData.name
            ensureSetListButtonTooltip(button)
            setSetListButtonIcon(button, getSetListIconItemId(setData))
        end
        state.selectedSavedSetName = nil
    else
        for _, setData in ipairs(state.itemSetCatalog) do
            local buttonId = listFrame:AddItem(getCatalogSetRowLabel(setData))
            local button = listFrame:GetButton(buttonId)
            button.itemSetId = tonumber(setData.id)
            button.fullLabelText = tostring(setData.displayName or setData.name or "Set")
            ensureSetListButtonTooltip(button)
            setSetListButtonIcon(button, getSetListIconItemId(setData))
        end
        state.selectedCatalogSetId = nil
    end

    setsFrame.listScroll:UpdateScrollChildRect()
    do
        local maxScroll = math.max(0, (listFrame:GetHeight() or 0) - (setsFrame.listScroll:GetHeight() or 0))
        local currentScroll = reselectValue ~= nil and (setsFrame.listScroll:GetVerticalScroll() or 0) or 0
        if currentScroll > maxScroll then
            currentScroll = maxScroll
        end
        if currentScroll < 0 then
            currentScroll = 0
        end
        setsFrame.listScroll:SetVerticalScroll(currentScroll)
    end
    if ns.RefreshManagedScrollFrame then
        ns.RefreshManagedScrollFrame(setsFrame.listScroll)
    end

    if reselectValue ~= nil then
        for index = 1, listFrame:GetSize() do
            local button = listFrame:GetButton(index)
            if state.setSource == SET_SOURCE_SAVED then
                if button and button.setName == reselectValue then
                    listFrame:Select(index)
                    break
                end
            elseif button and tonumber(button.itemSetId) == tonumber(reselectValue) then
                listFrame:Select(index)
                break
            end
        end
    end

    updateSetButtons()
    updateSetPreview()
end

transmogTab.setsFrame.list.onSelect = function(self, id)
    local button = self:GetButton(id)
    if state.setSource == SET_SOURCE_SAVED then
        state.selectedSavedSetName = button and button.setName or nil
    else
        state.selectedCatalogSetId = button and tonumber(button.itemSetId) or nil
    end

    updateSetButtons()
    updateSetPreview()
end

local function saveCurrentPreviewAsNamedSet(name)
    name = trim(name)
    if name == "" then
        return
    end

    local savedSets = getSavedTransmogSets()
    local snapshot = snapshotCurrentTransmogSet()
    local existing = nil

    for index, setData in ipairs(savedSets) do
        if setData.name == name then
            existing = index
            break
        end
    end

    if existing then
        savedSets[existing].items = snapshot
    else
        table.insert(savedSets, {
            name = name,
            items = snapshot,
        })
    end

    state.setSource = SET_SOURCE_SAVED
    state.selectedSavedSetName = name
    rebuildSetLists()
    updateSetButtons()
    updateSetPreview()
end

local function showSaveCurrentSetDialog()
    if not state.synced then
        SELECTED_CHAT_FRAME:AddMessage("|ccff6ff98<Appearance Buddy>|r: wait for transmog data to finish syncing before saving a transmog set.")
        return
    end

    StaticPopupDialogs["APPEARANCE_BUDDY_TRANSMOG_SET_SAVE_DIALOG"] = {
        text = "Enter transmog set name:",
        button1 = "Save",
        button2 = "Cancel",
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        hasEditBox = true,
        hasWideEditBox = true,
        maxLetters = 50,
        preferredIndex = 3,
        OnShow = function(self)
            self.button1:Disable()
            self.wideEditBox:SetText("")
            self.originalOnChange = self.wideEditBox:GetScript("OnTextChanged")
            self.wideEditBox:SetScript("OnTextChanged", function(editBox, ...)
                local text = trim(editBox:GetText())
                if text == "" then
                    self.button1:Disable()
                else
                    self.button1:Enable()
                end
                if self.originalOnChange then
                    self.originalOnChange(editBox, ...)
                end
            end)
        end,
        OnAccept = function(self)
            local enteredName = trim(self.wideEditBox:GetText())
            self.wideEditBox:SetScript("OnTextChanged", self.originalOnChange)
            self.originalOnChange = nil
            saveCurrentPreviewAsNamedSet(enteredName)
        end,
        OnCancel = function(self)
            self.wideEditBox:SetScript("OnTextChanged", self.originalOnChange)
            self.originalOnChange = nil
        end,
    }

    StaticPopup_Show("APPEARANCE_BUDDY_TRANSMOG_SET_SAVE_DIALOG")
end

local function removeSelectedSavedSet()
    local selectedName = state.selectedSavedSetName
    if not selectedName then
        return
    end

    local savedSets = getSavedTransmogSets()
    for index, setData in ipairs(savedSets) do
        if setData.name == selectedName then
            table.remove(savedSets, index)
            break
        end
    end

    state.selectedSavedSetName = nil
    rebuildSetLists()
end

local function updateViewMode()
    local isItems = state.viewMode == "items"
    local isSets = state.viewMode == "sets"

    updateModeButtons()
    setItemModeVisible(isItems)

    if isItems then
        transmogTab.setsFrame:Hide()
        if ns.RefreshManagedScrollFrame then
            ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll, false)
        end
        transmogTab.buttonApply:Show()
        transmogTab.buttonHide:Show()
        transmogTab.buttonRestore:Show()
        transmogTab.buttonRevert:Show()
        transmogTab.buttonRevertAll:Show()
        transmogTab.buttonApplyAll:Show()
        if not state.enabled then
            showListMessage(state.disabledReason or "Transmog is unavailable.")
        else
            loadCurrentSlotItems()
        end
        updateStatusText()
        updateActionButtons()
    else
        transmogTab.setsFrame:Show()
        if ns.RefreshManagedScrollFrame then
            ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll)
        end
        rebuildSetLists()
        if state.setSource == SET_SOURCE_CATALOG and state.enabled then
            refreshItemSetCatalogIfNeeded(false)
        end
    end
end

local function setSetSource(source)
    if source ~= SET_SOURCE_SAVED and source ~= SET_SOURCE_CATALOG then
        return
    end

    state.setSource = source
    rebuildSetLists()

    if source == SET_SOURCE_CATALOG and state.enabled then
        refreshItemSetCatalogIfNeeded(false)
    end
end

transmogTab.buttonModeItems:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    state.viewMode = "items"
    updateViewMode()
end)

transmogTab.buttonModeSets:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    state.viewMode = "sets"
    updateViewMode()
end)

transmogTab.setsFrame.buttonSourceSaved:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    setSetSource(SET_SOURCE_SAVED)
end)

transmogTab.setsFrame.buttonSourceCatalog:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    setSetSource(SET_SOURCE_CATALOG)
end)

transmogTab.setsFrame.buttonCopyCurrent:SetScript("OnClick", function()
    PlaySound("gsTitleOptionOK")
    showSaveCurrentSetDialog()
end)

transmogTab.setsFrame.buttonRemoveSaved:SetScript("OnClick", function()
    if not state.selectedSavedSetName then
        return
    end

    PlaySound("gsTitleOptionOK")
    removeSelectedSavedSet()
end)

transmogTab.setsFrame.buttonRefreshCatalog:SetScript("OnClick", function()
    if not state.enabled then
        return
    end

    PlaySound("gsTitleOptionOK")
    refreshItemSetCatalogIfNeeded(true)
end)

transmogTab.setsFrame.buttonApplySelected:SetScript("OnClick", function()
    if state.setSource == SET_SOURCE_SAVED then
        local savedSet = getSelectedSavedSet()
        if savedSet then
            PlaySound("gsTitleOptionOK")
            applyAppearanceSetAsTransmog(savedSet.items)
        end
    else
        local catalogSet = getSelectedCatalogSet()
        if catalogSet then
            PlaySound("gsTitleOptionOK")
            applyUnlockedCatalogSet(catalogSet.id)
        end
    end
end)

local handlers = {}

handlers.InitTab = function(player, itemIds, page, hasMorePages, slotId, requestToken)
    local responseSlot = SLOT_NAME_BY_ID[tonumber(slotId)] or state.currentSlot
    local responseToken = tonumber(requestToken)

    if responseToken and responseToken ~= state.requestToken then
        return
    end

    if responseSlot ~= state.currentSlot then
        return
    end

    state.currentPage = tonumber(page) or 1
    state.hasMorePages = hasMorePages and true or false
    if trim(transmogTab.searchBox:GetText()) == "" then
        rememberSlotPage(responseSlot, state.currentPage)
    end

    updatePageText()
    updateCandidateList(itemIds or {})
end

-- Response handler for SetUnobtainedSlotItemIds / SetSearchUnobtainedSlotItemIds.
-- The server should mirror the InitTab signature but subtract the player's unlocked set.
handlers.InitUnobtainedTab = function(player, itemIds, page, hasMorePages, slotId, requestToken)
    -- Unobtained browsing UI was removed; silently ignore server responses.
end

handlers.SetCurrentSlotItemPageClient = function(player, slotId, page, requestToken)
    local responseSlot = SLOT_NAME_BY_ID[tonumber(slotId)] or state.currentSlot
    local responseToken = tonumber(requestToken)
    local currentSearch = trim(transmogTab.searchBox:GetText())

    if responseToken and responseToken ~= state.pageLookupToken then
        return
    end

    if responseSlot ~= state.currentSlot or currentSearch ~= "" then
        return
    end

    if state.pageLookupSlot ~= responseSlot then
        return
    end

    if (tonumber(state.pageLookupAnchor) or 0) ~= getCurrentSlotPageAnchor(responseSlot) then
        return
    end

    state.currentPage = tonumber(page) or 1
    if state.currentPage < 1 then
        state.currentPage = 1
    end

    rememberSlotPage(responseSlot, state.currentPage, state.pageLookupAnchor)
    state.pageLookupSlot = nil
    state.pageLookupAnchor = nil
    requestCurrentSlotItems(false)
end

handlers.SetTransmogItemIdClient = function(player, slotId, itemId, realItemId)
    local slotName = SLOT_NAME_BY_ID[tonumber(slotId)]
    if not slotName then
        return
    end

    local previousServerState = state.server[slotName]
    local previewState = state.preview[slotName]
    local previewUntouched = previewState
        and previewState.mode == "restore"
        and previewState.itemId == nil
        and previewState.effectiveId == nil
    local isInitialSlotSync = previewUntouched
        and previousServerState
        and previousServerState.itemId == nil
        and previousServerState.realItemId == nil

    state.synced = true
    state.server[slotName] = normalizeServerState(itemId, realItemId, slotName)

    if state.applyingAppearanceSet or state.applyingUnlockedItemSet or isInitialSlotSync or not isSlotDirty(slotName) then
        copyServerToPreview(slotName)
    elseif state.preview[slotName].mode == "restore" then
        state.preview[slotName].effectiveId = state.server[slotName].realItemId
    elseif state.preview[slotName].mode == "item" and state.server[slotName].realItemId and state.preview[slotName].itemId == state.server[slotName].realItemId then
        setPreviewToRestore(slotName)
    end

    refreshSlotButton(slotName)

    if transmogTab:IsShown() then
        updatePreviewModel()
        updateStatusText()
        updateActionButtons()
        if slotName == state.currentSlot then
            updateListSelection()
        end
        if state.viewMode == "sets" then
            updateSetPreview()
        end
    end
end

handlers.LoadTransmogsAfterSave = function()
    if transmogTab:IsShown() and state.synced then
        updatePreviewModel()
    end
end

handlers.InitItemSets = function(player, itemSets)
    state.itemSetCatalog = type(itemSets) == "table" and itemSets or {}
    state.itemSetCatalogLoaded = true
    state.itemSetCatalogRequestPending = false
    state.itemSetCatalogRequestStartedAt = 0
    state.itemSetCatalogLastRefreshAt = GetTime and GetTime() or 0
    state.itemSetCatalogDirty = false
    state.itemSetCatalogDirtyAt = 0

    if state.viewMode == "sets" and state.setSource == SET_SOURCE_CATALOG then
        rebuildSetLists()
    end
end

do
    local catalogTimeoutFrame = CreateFrame("Frame")
    catalogTimeoutFrame:SetScript("OnUpdate", function()
        if not state.itemSetCatalogRequestPending then
            return
        end

        local now = GetTime and GetTime() or 0
        if now <= 0 or (now - (state.itemSetCatalogRequestStartedAt or 0)) < 4 then
            return
        end

        state.itemSetCatalogRequestPending = false
        state.itemSetCatalogRequestStartedAt = 0

        if state.viewMode == "sets" and state.setSource == SET_SOURCE_CATALOG then
            transmogTab.setsFrame.previewTitle:SetText("Item Sets Unavailable")
            transmogTab.setsFrame.previewInfo:SetText("No response from the server item-set handler.\nReload or restart transmog.lua, then click Refresh.")
            transmogTab.setsFrame.previewModel:Undress()
            updateSetButtons()
        end
    end)
end

handlers.AppearanceSetResult = function(player, appliedCount, hiddenCount, missingSlots, restoredCount)
    state.applyingAppearanceSet = false

    appliedCount = tonumber(appliedCount) or 0
    hiddenCount = tonumber(hiddenCount) or 0
    restoredCount = tonumber(restoredCount) or 0
    missingSlots = tostring(missingSlots or "")

    local parts = {}
    if appliedCount > 0 then
        table.insert(parts, ("%d appearance%s applied"):format(appliedCount, appliedCount == 1 and "" or "s"))
    end
    if hiddenCount > 0 then
        table.insert(parts, ("%d slot%s hidden"):format(hiddenCount, hiddenCount == 1 and "" or "s"))
    end
    if restoredCount > 0 then
        table.insert(parts, ("%d slot%s restored"):format(restoredCount, restoredCount == 1 and "" or "s"))
    end
    if missingSlots ~= "" then
        table.insert(parts, "Missing unlocks: "..missingSlots)
    end
    if #parts == 0 then
        table.insert(parts, "No appearance set changes were applied")
    end

    if transmogTab:IsShown() and state.viewMode == "sets" then
        updateSetButtons()
    end

end

handlers.UnlockedItemSetResult = function(player, setName, appliedCount, hiddenCount, missingSlots)
    state.applyingUnlockedItemSet = false

    if missingSlots == nil and type(hiddenCount) == "string" then
        missingSlots = hiddenCount
        hiddenCount = 0
    end

    setName = tostring(setName or "item set")
    appliedCount = tonumber(appliedCount) or 0
    hiddenCount = tonumber(hiddenCount) or 0
    missingSlots = tostring(missingSlots or "")

    local parts = {
        ("%s applied to %d slot%s"):format(setName, appliedCount, appliedCount == 1 and "" or "s")
    }
    if hiddenCount > 0 then
        table.insert(parts, ("%d non-set armor slot%s hidden"):format(hiddenCount, hiddenCount == 1 and "" or "s"))
    end
    if missingSlots ~= "" then
        table.insert(parts, "Missing unlocks: "..missingSlots)
    end

    if transmogTab:IsShown() and state.viewMode == "sets" then
        updateSetButtons()
    end

end

-- Sent by the server when a player interacts with a transmogrifier NPC.
handlers.TransmogFrame = function()
    if ns.mainFrame and not ns.mainFrame:IsShown() then
        ns.mainFrame:Show()
    end
end

if state.enabled then
    local ok, err = pcall(function()
        AIO.AddHandlers("Transmog", handlers)
    end)

    if not ok then
        state.enabled = false
        state.disabledReason = "Transmog bridge unavailable. Disable the legacy transmog client if it is still loaded."
    end
else
    state.disabledReason = "AIO is not available, so Appearance Buddy cannot reach the server transmog handlers."
end

ns.ApplyAppearanceSetAsTransmog = applyAppearanceSetAsTransmog
ns.IsTransmogAvailable = function()
    return state.enabled
end

transmogTab:EnableMouseWheel(true)
transmogTab:SetScript("OnMouseWheel", handlePageScroll)
transmogTab.list:EnableMouseWheel(true)
transmogTab.list:SetScript("OnMouseWheel", handlePageScroll)
transmogTab.searchBox:EnableMouseWheel(true)
transmogTab.searchBox:SetScript("OnMouseWheel", handlePageScroll)
mainFrame:EnableMouseWheel(true)
mainFrame:SetScript("OnMouseWheel", handlePageScroll)

do
    local dressingRoom = mainFrame.dressingRoom
    local originalOnMouseWheel = dressingRoom:GetScript("OnMouseWheel")

    dressingRoom:SetScript("OnMouseWheel", function(self, delta)
        if originalOnMouseWheel then
            originalOnMouseWheel(self, delta)
        end
    end)
end

transmogTab:SetScript("OnShow", function()
    if ns.SetAppearanceBuddyPreviewControlsVisible then
        ns.SetAppearanceBuddyPreviewControlsVisible(false)
    end

    state.previousUnit = mainFrame.dressingRoom.GetUnitToken and mainFrame.dressingRoom:GetUnitToken() or "player"
    saveDressingRoomView()
    mainFrame.dressingRoom:SetUnit("player")
    setTransmogDressingRoomView()

    selectSlot(state.currentSlot)
    refreshAllSlotButtons()
    updateStatusText()
    updateActionButtons()

    if state.enabled and not state.synced then
        AIO.Handle("Transmog", "SetTransmogItemIds")
    elseif state.enabled and state.viewMode == "items" and transmogTab.list:IsShown() then
        transmogTab.list.skipUndress = (state.currentSlot == "Main Hand" or state.currentSlot == "Off-hand")
        transmogTab.list:Update()
    end

    updatePreviewModel()
    updateViewMode()
    refreshItemSetCatalogIfNeeded(false)
    if ns.RefreshManagedScrollFrame then
        if state.viewMode == "sets" then
            ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll)
        else
            ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll, false)
        end
    end
end)

transmogTab:SetScript("OnHide", function()
    if ns.SetAppearanceBuddyPreviewControlsVisible then
        ns.SetAppearanceBuddyPreviewControlsVisible(true)
    end

    -- Hide the global transmog buttons (parented to mainFrame, not transmogTab)
    transmogTab.buttonRevertAll:Hide()
    transmogTab.buttonRevert:Hide()
    transmogTab.buttonApplyAll:Hide()

    -- Only restore real gear and camera when the window fully closes.
    -- When switching to another tab (mainFrame still visible), keep the
    -- transmog preview on the model so the appearance stays consistent.
    if not mainFrame:IsShown() then
        if ns.RefreshDressingRoomFromSlots then
            ns.RefreshDressingRoomFromSlots(state.previousUnit)
        end
        restoreDressingRoomView()
    end

    if ns.RefreshManagedScrollFrame then
        ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll, false)
    end
end)

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
eventFrame:RegisterEvent("BAG_UPDATE")
eventFrame:SetScript("OnEvent", function(self, event)
    if not state.enabled then
        return
    end

    if event == "PLAYER_ENTERING_WORLD" then
        lastBagContentsSignature = nil
        invalidateItemSetCatalog()
        AIO.Handle("Transmog", "LoadPlayer")
        requestServerState()
        if state.viewMode == "sets" and state.setSource == SET_SOURCE_CATALOG then
            refreshItemSetCatalogIfNeeded(false)
        end
        scheduleBagAppearanceScan(true, 0.5)
    elseif event == "PLAYER_EQUIPMENT_CHANGED" then
        invalidateItemSetCatalog()
        AIO.Handle("Transmog", "OnUnequipItem")
        requestServerState()
        if state.viewMode == "sets" and state.setSource == SET_SOURCE_CATALOG then
            refreshItemSetCatalogIfNeeded(false)
        end
        scheduleBagAppearanceScan(false, 0.1)
    elseif event == "BAG_UPDATE" then
        invalidateItemSetCatalog()
        scheduleBagAppearanceScan(false, 0.2)
    end
end)

copyAllServerToPreview()
selectSlot(state.currentSlot)
refreshAllSlotButtons()
updatePageText()
updateStatusText()
updateActionButtons()
sortSavedTransmogSets()
rebuildSetLists()
updateModeButtons()
setItemModeVisible(state.viewMode == "items")
if state.viewMode == "items" then
    transmogTab.setsFrame:Hide()
    if ns.RefreshManagedScrollFrame then
        ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll, false)
    end
else
    transmogTab.setsFrame:Show()
    if ns.RefreshManagedScrollFrame then
        ns.RefreshManagedScrollFrame(transmogTab.setsFrame.listScroll)
    end
end
