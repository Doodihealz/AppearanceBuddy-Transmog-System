local addon, ns = ...

local mainFrameTitle = "|ccff6ff98Appearance Buddy |cffffffff2.5.0|r"

local sex = UnitSex("player")
local _, raceFileName = UnitRace("player")
local _, classFileName = UnitClass("player")

local previewSetupVersion = "classic"

local armorSlots = {"Head", "Shoulder", "Chest", "Wrist", "Hands", "Waist", "Legs", "Feet"}
local backSlot = "Back"
local miscellaneousSlots = {"Tabard", "Shirt"}
local mainHandSlot = "Main Hand"
local offHandSlot = "Off-hand"
local rangedSlot = "Ranged"

-- For hiding hair/beard
local chestSlots = {"Chest", "Tabard", "Shirt"}

local addonMessagePrefix = "AppearanceBuddy"
-- Used in look saving/sending. Changing will break compatibility.
local slotOrder = { "Head", "Shoulder", "Back", "Chest", "Shirt", "Tabard", "Wrist", "Hands", "Waist", "Legs", "Feet", "Main Hand", "Off-hand", "Ranged",}

local slotTextures = {
    ["Head"] =      "Interface\\Paperdoll\\ui-paperdoll-slot-head",
    ["Shoulder"] =  "Interface\\Paperdoll\\ui-paperdoll-slot-shoulder",
    ["Back"] =      "Interface\\Paperdoll\\ui-paperdoll-slot-chest",
    ["Chest"] =     "Interface\\Paperdoll\\ui-paperdoll-slot-chest",
    ["Shirt"] =     "Interface\\Paperdoll\\ui-paperdoll-slot-shirt",
    ["Tabard"] =    "Interface\\Paperdoll\\ui-paperdoll-slot-tabard",
    ["Wrist"] =     "Interface\\Paperdoll\\ui-paperdoll-slot-wrists",
    ["Hands"] =     "Interface\\Paperdoll\\ui-paperdoll-slot-hands",
    ["Waist"] =     "Interface\\Paperdoll\\ui-paperdoll-slot-waist",
    ["Legs"] =      "Interface\\Paperdoll\\ui-paperdoll-slot-legs",
    ["Feet"] =      "Interface\\Paperdoll\\ui-paperdoll-slot-feet",
    ["Main Hand"] = "Interface\\Paperdoll\\ui-paperdoll-slot-mainhand",
    ["Off-hand"] =  "Interface\\Paperdoll\\ui-paperdoll-slot-secondaryhand",
    ["Ranged"] =    "Interface\\Paperdoll\\ui-paperdoll-slot-ranged",
}

local slotSubclasses = {--[[
    ["slot1"] = {subclass1, subclass2, ...},
    ["slot2"] = {subclass1, subclass2, ...},
    ["slot2"] = {subclass1, subclass2, ...},
    ...]]
}

do
    for i, slot in ipairs(armorSlots) do slotSubclasses[slot] = {"Cloth", "Leather", "Mail", "Plate"} end
    for i, slot in ipairs(miscellaneousSlots) do slotSubclasses[slot] = {"Miscellaneous", } end
    slotSubclasses[backSlot] = {"Cloth", }
    slotSubclasses[mainHandSlot] = {
        "1H Axe", "1H Mace", "1H Sword", "1H Dagger", "1H Fist",
        "MH Axe", "MH Mace", "MH Sword", "MH Dagger", "MH Fist",
        "2H Axe", "2H Mace", "2H Sword", "Polearm", "Staff" }
    slotSubclasses[offHandSlot] = { "OH Axe", "OH Mace", "OH Sword", "OH Dagger", "OH Fist", "Shield", "Held in Off-hand"}
    slotSubclasses[rangedSlot] = {"Bow", "Crossbow", "Gun", "Wand", "Thrown"}
end

local defaultSlot = "Head"

local defaultArmorSubclass = {
    ["MAGE"] = "Cloth",
    ["PRIEST"] = "Cloth",
    ["WARLOCK"] = "Cloth",
    ["DRUID"] = "Leather",
    ["ROGUE"] = "Leather",
    ["HUNTER"] = "Mail",
    ["SHAMAN"] = "Mail",
    ["PALADIN"] = "Plate",
    ["WARRIOR"] = "Plate",
    ["DEATHKNIGHT"] = "Plate"
}


local defaultSettings = {
    dressingRoomBackgroundColor = {0.6, 0.6, 0.6, 1},
    dressingRoomBackgroundTexture = {
        [GetRealmName()] = {
            [GetUnitName("player")] = classFileName == "DEATHKNIGHT" and classFileName or raceFileName,
        },
    },
    previewSetup = "classic", -- possible values are "classic" and "modern",
    showAppearanceBuddyButton = true,
    showShortcutsInTooltip = true,
    ignoreUIScaling = false,
    windowLocked = false,
}

local function GetSettings()
    local function copyTable(tableFrom)
        local result = {}
        for k, v in pairs(tableFrom) do
            if type(v) == "table" then
                result[k] = copyTable(v)
            else
                result[k] = v
            end
        end
        return result
    end

    -- Migrate from old DressMe variable name
    if _G["AppearanceBuddySettings"] == nil and type(_G["DressMeSettings"]) == "table" then
        _G["AppearanceBuddySettings"] = copyTable(_G["DressMeSettings"])
        _G["DressMeSettings"] = nil
    end

    if _G["AppearanceBuddySettings"] == nil then
        _G["AppearanceBuddySettings"] = copyTable(defaultSettings)
    else
        for k, v in pairs(defaultSettings) do
            if _G["AppearanceBuddySettings"][k] == nil then
                _G["AppearanceBuddySettings"][k] = type(v) == "table" and copyTable(v) or v
            end
        end
        if _G["AppearanceBuddySettings"].dressingRoomBackgroundTexture[GetRealmName()] == nil then
            _G["AppearanceBuddySettings"].dressingRoomBackgroundTexture[GetRealmName()] = {}
        end
        if _G["AppearanceBuddySettings"].dressingRoomBackgroundTexture[GetRealmName()][GetUnitName("player")] == nil then
            _G["AppearanceBuddySettings"].dressingRoomBackgroundTexture[GetRealmName()][GetUnitName("player")] = defaultSettings.dressingRoomBackgroundTexture[GetRealmName()][GetUnitName("player")]
        end
    end

    return _G["AppearanceBuddySettings"]
end


local function arrayHasValue(array, value)
    for i, v in ipairs(array) do
        if v == value then
            return true
        end
    end
    return false
end

local function getManagedScrollFrameParts(scrollFrame)
    if not scrollFrame then
        return nil, nil, nil
    end

    local scrollBar = scrollFrame.ScrollBar
    if not scrollBar and scrollFrame.GetName then
        local frameName = scrollFrame:GetName()
        if frameName and frameName ~= "" then
            scrollBar = _G[frameName.."ScrollBar"]
        end
    end
    if not scrollBar then
        return nil, nil, nil
    end

    local scrollUpButton = scrollBar.ScrollUpButton or _G[scrollBar:GetName().."ScrollUpButton"]
    local scrollDownButton = scrollBar.ScrollDownButton or _G[scrollBar:GetName().."ScrollDownButton"]
    return scrollBar, scrollUpButton, scrollDownButton
end

local function RefreshManagedScrollFrame(scrollFrame, forcedVisibility)
    local scrollBar, scrollUpButton, scrollDownButton = getManagedScrollFrameParts(scrollFrame)
    if not scrollBar then
        return
    end

    local shouldShow
    if forcedVisibility ~= nil then
        shouldShow = forcedVisibility and true or false
    else
        shouldShow = false
        if scrollFrame:IsVisible() then
            local scrollChild = scrollFrame:GetScrollChild()
            local childHeight = scrollChild and tonumber(scrollChild:GetHeight()) or 0
            local frameHeight = tonumber(scrollFrame:GetHeight()) or 0
            shouldShow = childHeight > frameHeight + 1
        end
    end

    if shouldShow then scrollBar:Show() else scrollBar:Hide() end
    if scrollUpButton then
        if shouldShow then scrollUpButton:Show() else scrollUpButton:Hide() end
    end
    if scrollDownButton then
        if shouldShow then scrollDownButton:Show() else scrollDownButton:Hide() end
    end

    if not shouldShow and scrollFrame.SetVerticalScroll then
        scrollFrame:SetVerticalScroll(0)
    end
end

local function IsWindowLocked()
    return GetSettings().windowLocked and true or false
end


local dressingRoomBorderBackdrop = { -- For a frame above DressingRoom
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
	edgeFile = "Interface\\AddOns\\AppearanceBuddy\\images\\mirror-border",
	tile = false, tileSize = 16, edgeSize = 32,
	insets = { left = 4, right = 4, top = 4, bottom = 4 }
}


local mainFrame = CreateFrame("Frame", addon, UIParent)
-- "Hurry up! You must hack the main frame!"
-- <hackerman noises>
table.insert(UISpecialFrames, mainFrame:GetName())
do 
    mainFrame:SetWidth(1045)
    mainFrame:SetHeight(505)
    mainFrame:SetPoint("CENTER")
    mainFrame:Hide()
    mainFrame:SetMovable(true)
    mainFrame:EnableMouse(true)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", function(self)
        if not IsWindowLocked() then
            self:StartMoving()
        end
    end)
    mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing)
    mainFrame:SetScript("OnShow", function()
        PlaySound("igCharacterInfoOpen")
        if _G["TempEnchant1"] then _G["TempEnchant1"]:Hide() end
        if _G["TempEnchant2"] then _G["TempEnchant2"]:Hide() end
    end)
    mainFrame:SetScript("OnHide", function()
        PlaySound("igCharacterInfoClose")
        if _G["TempEnchant1"] then _G["TempEnchant1"]:Show() end
        if _G["TempEnchant2"] then _G["TempEnchant2"]:Show() end
    end)

    local title = mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -9)
    title:SetText(mainFrameTitle)

    local titleBg = mainFrame:CreateTexture(nil, "BACKGROUND")
	titleBg:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Title-Background")
	titleBg:SetPoint("TOPLEFT", 10, -7)
    titleBg:SetPoint("BOTTOMRIGHT", mainFrame, "TOPRIGHT", -28, -24)

	local menuBg = mainFrame:CreateTexture(nil, "BACKGROUND")
    menuBg:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopBackground")
    menuBg:SetTexCoord(0, 1, 0, 0.8125) 
	menuBg:SetPoint("TOPLEFT", 10, -26)
    menuBg:SetPoint("RIGHT", -6, 0)
    menuBg:SetHeight(48)
    menuBg:SetVertexColor(0.5, 0.5, 0.5)

    local frameBg = mainFrame:CreateTexture(nil, "BACKGROUND")
    frameBg:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopBackground")
    frameBg:SetTexCoord(0, 0.5, 0, 0.8125) 
    frameBg:SetPoint("TOPLEFT", menuBg, "BOTTOMLEFT")
    frameBg:SetPoint("TOPRIGHT", menuBg, "BOTTOMRIGHT")
    frameBg:SetPoint("BOTTOM", 0, 5)
    frameBg:SetVertexColor(0.25, 0.25, 0.25)
	
	local topLeft = mainFrame:CreateTexture(nil, "BORDER")
    topLeft:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    topLeft:SetTexCoord(0.5, 0.625, 0, 1)
	topLeft:SetWidth(64)
	topLeft:SetHeight(64)
	topLeft:SetPoint("TOPLEFT")
	
	local topRight = mainFrame:CreateTexture(nil, "BORDER")
    topRight:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    topRight:SetTexCoord(0.625, 0.75, 0, 1)
	topRight:SetWidth(64)
	topRight:SetHeight(64)
    topRight:SetPoint("TOPRIGHT")
	
	local top = mainFrame:CreateTexture(nil, "BORDER")
    top:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    top:SetTexCoord(0.25, 0.37, 0, 1)
	top:SetPoint("TOPLEFT", topLeft, "TOPRIGHT")
    top:SetPoint("TOPRIGHT", topRight, "TOPLEFT")

    local menuSeparatorLeft = mainFrame:CreateTexture(nil, "BORDER")
    menuSeparatorLeft:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    menuSeparatorLeft:SetTexCoord(0.5, 0.5546875, 0.25, 0.53125)
	menuSeparatorLeft:SetPoint("TOPLEFT", topLeft, "BOTTOMLEFT")
    menuSeparatorLeft:SetWidth(28)
    menuSeparatorLeft:SetHeight(18)

    local menuSeparatorRight = mainFrame:CreateTexture(nil, "BORDER")
    menuSeparatorRight:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    menuSeparatorRight:SetTexCoord(0.7109375, 0.75, 0.25, 0.53125)
	menuSeparatorRight:SetPoint("TOPRIGHT", topRight, "BOTTOMRIGHT")
    menuSeparatorRight:SetWidth(20)
    menuSeparatorRight:SetHeight(18)

    local menuSeparatorCenter = mainFrame:CreateTexture(nil, "BORDER")
    menuSeparatorCenter:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    menuSeparatorCenter:SetTexCoord(0.564453125, 0.671875, 0.25, 0.53125)
    menuSeparatorCenter:SetPoint("TOPLEFT", menuSeparatorLeft, "TOPRIGHT")
    menuSeparatorCenter:SetPoint("BOTTOMRIGHT", menuSeparatorRight, "BOTTOMLEFT")

    local botLeft = mainFrame:CreateTexture(nil, "BORDER")
    botLeft:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    botLeft:SetTexCoord(0.75, 0.875, 0, 1)
	botLeft:SetPoint("BOTTOMLEFT")
    botLeft:SetWidth(64)
    botLeft:SetHeight(64)

    local left = mainFrame:CreateTexture(nil, "BORDER")
    left:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    left:SetTexCoord(0, 0.125, 0, 1)
    left:SetPoint("TOPLEFT", menuSeparatorLeft, "BOTTOMLEFT")
    left:SetPoint("BOTTOMRIGHT", botLeft, "TOPRIGHT")

    local botRight = mainFrame:CreateTexture(nil, "BORDER")
    botRight:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    botRight:SetTexCoord(0.875, 1, 0, 1)
	botRight:SetPoint("BOTTOMRIGHT")
    botRight:SetWidth(64)
    botRight:SetHeight(64)

    local right = mainFrame:CreateTexture(nil, "BORDER")
    right:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    right:SetTexCoord(0.125, 0.25, 0, 1)
    right:SetPoint("TOPRIGHT", menuSeparatorRight, "BOTTOMRIGHT", 4, 0)
    right:SetPoint("BOTTOMLEFT", botRight, "TOPLEFT", 4, 0)

    local bot = mainFrame:CreateTexture(nil, "BORDER")
    bot:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    bot:SetTexCoord(0.38, 0.45, 0, 1)
    bot:SetPoint("BOTTOMLEFT", botLeft, "BOTTOMRIGHT")
    bot:SetPoint("TOPRIGHT", botRight, "TOPLEFT")

    local separatorV = mainFrame:CreateTexture(nil, "BORDER")
    separatorV:SetTexture("Interface\\PaperDollInfoFrame\\UI-GearManager-Border")
    separatorV:SetTexCoord(0.23046875, 0.236328125, 0, 1)
    separatorV:SetPoint("TOPLEFT", 410, -72)
    separatorV:SetPoint("BOTTOM", 0, 32)
    separatorV:SetWidth(3)
    separatorV:SetVertexColor(0.5, 0.5, 0.5)
    
    mainFrame.stats = CreateFrame("Frame", nil, mainFrame)
    local stats = mainFrame.stats
    stats:SetBackdrop({
        bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
	    tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 3, right = 3, top = 5, bottom = 3 }
    })
    stats:SetBackdropColor(0.12, 0.12, 0.12)
    stats:SetBackdropBorderColor(0.25, 0.25, 0.25)
    stats:SetPoint("BOTTOMLEFT", 410, 8)
    stats:SetPoint("BOTTOMRIGHT", -6, 8)
    stats:SetHeight(24)

    mainFrame.buttons = {}

    local function UpdateWindowLockState()
        local locked = IsWindowLocked()
        mainFrame:SetMovable(not locked)
        if locked then
            mainFrame:StopMovingOrSizing()
        end
    end

	local close = CreateFrame("Button", nil, mainFrame, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 1)
    close:SetScript("OnClick", function(self)
        self:GetParent():Hide()
    end)

    mainFrame.buttons.close = close
    mainFrame.UpdateWindowLockState = UpdateWindowLockState
    UpdateWindowLockState()
end


mainFrame.dressingRoom = ns.CreateDressingRoom(nil, mainFrame)

do
    local dr = mainFrame.dressingRoom
    dr:SetPoint("TOPLEFT", 10, -74)
    dr:SetSize(400, 400)

    local border = CreateFrame("Frame", nil, dr)
    border:SetAllPoints()
    border:SetBackdrop(dressingRoomBorderBackdrop)
    border:SetBackdropColor(0, 0, 0, 0)

    dr.backgroundTextures = {}
    for s in ("human,nightelf,dwarf,gnome,draenei,orc,scourge,tauren,troll,bloodelf,deathknight"):gmatch("%w+") do
        dr.backgroundTextures[s] = dr:CreateTexture(nil, "BACKGROUND")
        dr.backgroundTextures[s]:SetTexture("Interface\\AddOns\\AppearanceBuddy\\images\\"..s)
        dr.backgroundTextures[s]:SetAllPoints()
        dr.backgroundTextures[s]:Hide()
    end
    dr.backgroundTextures["color"] = dr:CreateTexture(nil, "BACKGROUND")
    dr.backgroundTextures["color"]:SetAllPoints()
    dr.backgroundTextures["color"]:SetTexture(1, 1, 1)
    dr.backgroundTextures["color"]:Hide()

    local tip = dr:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    tip:SetPoint("BOTTOM", dr, "TOP", 0, 12)
    tip:SetJustifyH("CENTER")
    tip:SetJustifyV("BOTTOM")
    tip:SetText("\124cff00ff00Left Mouse:\124r rotate \124 \124cff00ff00Right Mouse:\124r pan\124n\124cff00ff00Wheel\124r or \124cff00ff00Alt + Right Mouse:\124r zoom")

    -- SetLight(enabled, omni, dirX, dirY, dirZ, ambIntensity, ambR, ambG, ambB, dirIntensity, dirR, dirG, dirB)
    local defaultLight = {1, 0, 0, 1, 0, 1, 0.7, 0.7, 0.7, 1, 0.8, 0.8, 0.64}
    local shadowformLight = {1, 0, 0, 1, 0, 1, 0.16, 0, 0.23, 0}
    local shadowformAlpha = 0.75

    dr.shadowformEnabled = false

    dr.EnableShadowform = function(self)
        self:SetLight(unpack(shadowformLight))
        self:SetModelAlpha(shadowformAlpha)
        self.shadowformEnabled = true
    end

    dr.DisableShadowform = function(self)
        self:SetLight(unpack(defaultLight))
        self:SetModelAlpha(1)
        self.shadowformEnabled = false
    end
end

mainFrame.buttons.send = CreateFrame("Button", "$parentButtonSend", mainFrame, "UIPanelButtonTemplate2")

do
    StaticPopupDialogs["APPEARANCE_BUDDY_SEND_DIALOG"] = {
        text = "|cffffd700Enter player name:",
        button1 = "Send",
        button2 = CLOSE,
        timeout = 0,
        whileDead = true,
        hasEditBox = true,
        preferredIndex = 3,
        OnAccept = function(self)
            local playerName = self.editBox:GetText()
            if playerName ~= "" then
                local slots = mainFrame.slots
                local s = slots[slotOrder[1]].itemId ~= nil and tostring(slots[slotOrder[1]].itemId) or ""
                local itemsCount = slots[slotOrder[1]].itemId == nil and 0 or 1
                for i=2, #slotOrder do
                    s = s..":"
                    if slots[slotOrder[i]].itemId ~= nil then
                        s = s..slots[slotOrder[i]].itemId
                        itemsCount = itemsCount + 1
                    end
                end
                if itemsCount > 0 then
                    SendAddonMessage(addonMessagePrefix, s, "WHISPER", playerName)
                else
                    SELECTED_CHAT_FRAME:AddMessage("|ccff6ff98<Appearance Buddy>|r: nothing to send.")
                end
            end
        end,
        OnShow = function(self)
            local data = self.data
            self.editBox:SetText("")
        end,}
    local btn = mainFrame.buttons.send
    btn:SetPoint("TOPRIGHT", mainFrame.dressingRoom, "BOTTOMRIGHT")
    btn:SetPoint("BOTTOM", mainFrame.stats, "BOTTOM", 0, 1)
    btn:SetWidth(mainFrame.dressingRoom:GetWidth()/4)
    btn:SetText("Send")
    btn:SetScript("OnClick", function()
        StaticPopup_Show("APPEARANCE_BUDDY_SEND_DIALOG")
        PlaySound("gsTitleOptionOK")
    end)
end

mainFrame.buttons.reset = CreateFrame("Button", "$parentButtonReset", mainFrame, "UIPanelButtonTemplate2")

do
    local btn = mainFrame.buttons.reset
    btn:SetPoint("TOPRIGHT", mainFrame.buttons.send, "TOPLEFT")
    btn:SetWidth(mainFrame.buttons.send:GetWidth())
    btn:SetText("Reset")
    btn:SetScript("OnClick", function()
        mainFrame.dressingRoom:Reset()
        PlaySound("gsTitleOptionOK")
    end)
end

mainFrame.buttons.undress = CreateFrame("Button", "$parentButtonUndress", mainFrame, "UIPanelButtonTemplate2")

do
    local btn = mainFrame.buttons.undress
    btn:SetPoint("TOPRIGHT", mainFrame.buttons.reset, "TOPLEFT")
    btn:SetPoint("BOTTOMRIGHT", mainFrame.buttons.reset, "BOTTOMLEFT")
    btn:SetWidth(mainFrame.buttons.reset:GetWidth())
    btn:SetText("Undress")
    btn:SetScript("OnClick", function()
        mainFrame.dressingRoom:Undress()
        PlaySound("gsTitleOptionOK")
    end)
end

mainFrame.buttons.useTarget = CreateFrame("Button", "$parentButtonUseTarget", mainFrame, "UIPanelButtonTemplate2")

do
    local btn = mainFrame.buttons.useTarget
    btn:SetPoint("TOPRIGHT", mainFrame.buttons.undress, "TOPLEFT")
    btn:SetWidth(mainFrame.buttons.undress:GetWidth())
    btn:SetText("Use Target")
    btn:SetScript("OnClick", function()
        mainFrame.dressingRoom:SetUnit("target")
        PlaySound("gsTitleOptionOK")
    end)
    btn:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Use target player's model.")
        GameTooltip:AddLine("The target must be in range of inspection.", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    btn:HookScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
end

---------------- TABS ----------------

local TAB_NAMES = {"Transmog", "Settings"}

mainFrame.tabs = {}

do
    local tabs = {}

    local function tab_OnClick(self)
        local selectedTab = PanelTemplates_GetSelectedTab(self:GetParent())
        local tab = tabs[selectedTab]
        if tab ~= nil then
            tab:Hide()
        end
        PanelTemplates_SetTab(self:GetParent(), self:GetID())
        tabs[self:GetID()]:Show()
        PlaySound("gsTitleOptionOK")
    end

    for i = 1, #TAB_NAMES do
        mainFrame.buttons["tab"..i] = CreateFrame("Button", "$parentTab"..i, mainFrame, "OptionsFrameTabButtonTemplate")
        local btn = mainFrame.buttons["tab"..i]
        btn:SetText(TAB_NAMES[i])
        btn:SetID(i)
        if i == 1 then
            btn:SetPoint("BOTTOMLEFT", btn:GetParent(), "TOPLEFT", 410, -70)
        else
            btn:SetPoint("LEFT", _G[mainFrame:GetName().."Tab"..(i - 1)], "RIGHT")
        end
        btn:SetScript("OnClick", tab_OnClick)

        local frame = CreateFrame("Frame", "$parentTab"..i.."Content", mainFrame)
        frame:SetPoint("TOPLEFT", 410, -73)
        frame:SetPoint("BOTTOMRIGHT", -8, 28)
        frame:Hide()
        table.insert(tabs, frame)
    end
    
    PanelTemplates_SetNumTabs(mainFrame, #TAB_NAMES)
    tab_OnClick(_G[mainFrame:GetName().."Tab1"])

    mainFrame.tabs.transmog = tabs[1]
    mainFrame.tabs.settings = tabs[2]
end

---------------- SLOTS ----------------

mainFrame.slots = {}
mainFrame.selectedSlot = nil

local function slot_OnShiftLeftClick(self)
    if self.itemId ~= nil then
        local _, link = GetItemInfo(self.itemId)
        if link ~= nil then
            SELECTED_CHAT_FRAME:AddMessage("|ccff6ff98<Appearance Buddy>|r: "..link.." ("..self.itemId..")")
        else
            SELECTED_CHAT_FRAME:AddMessage("|ccff6ff98<Appearance Buddy>|r: It seems this item cannot be used for transmogrification.")
        end
    end
end

local function getIndex(array, value)
    for i = 1, #array do
        if array[i] == value then
            return i    
        end
    end
    return nil
end

local function slot_OnControlLeftClick(self)
    if self.itemId ~= nil then
        ns.ShowWowheadURLDialog(self.itemId)
    end
end


local function slot_OnLeftClick(self)
    local selectedSlot = mainFrame.selectedSlot
    if selectedSlot ~= nil then
        selectedSlot:UnlockHighlight()
    end
    mainFrame.selectedSlot = self
    --[[ ReTryOn weapon so the model displays
    the weapon of the clicked (selected) slot. ]]
    if self.itemId ~= nil and getIndex({mainHandSlot, offHandSlot, rangedSlot}, self.slotName) then
        mainFrame.dressingRoom:TryOn(self.itemId)
    end
    self:LockHighlight()
end

local function slot_OnRightClick(self)
    self:RemoveItem()
end

local function slot_OnClick(self, button)
    if button == "LeftButton" then
        if IsShiftKeyDown() then
            slot_OnShiftLeftClick(self)
        elseif IsControlKeyDown() then
            slot_OnControlLeftClick(self)
        else
            slot_OnLeftClick(self)
        end
        PlaySound("gsTitleOptionOK")
    elseif button == "RightButton" then
        slot_OnRightClick(self)
    end
end

local function slot_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if self.itemId == nil then
        GameTooltip:AddLine(self.slotName)
    else
        local _, link = GetItemInfo(self.itemId)
        GameTooltip:SetHyperlink(link)
        if GetSettings().showShortcutsInTooltip then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("|cff00ff00Shift + Left Click:|r create a hyperlink for the item.")
            GameTooltip:AddLine("|cff00ff00Right Click:|r undress the slot.")
            GameTooltip:AddLine("|cff00ff00Ctrl + Left Click:|r create a Wowhead URL for the item.")
        end
    end
    GameTooltip:Show()
end

local function slot_OnLeave(self)
    GameTooltip:Hide()
end

local function slot_Reset(self)
    local characterSlotName = self.slotName
    if characterSlotName == mainHandSlot then characterSlotName = "MainHand" end
    if characterSlotName == offHandSlot then characterSlotName = "SecondaryHand" end
    if characterSlotName == rangedSlot then characterSlotName = "Ranged" end
    if characterSlotName == backSlot then characterSlotName = "Back" end
    local slotId = GetInventorySlotInfo(characterSlotName.."Slot")
    local itemId = GetInventoryItemID("player", slotId)
    local name, link, _, _, _, _, _, _, _, texture = GetItemInfo(itemId ~= nil and itemId or 0)
    if name ~= nil then
        self:SetItem(itemId)
    else
        self:RemoveItem()
    end
end

local function slot_RemoveItem(self)
    if self.itemId ~= nil then
        self.itemId = nil
        self.textures.empty:Show()
        self.textures.item:Hide()
        self:GetScript("OnEnter")(self)
        --[[ We cannot undress a specific slot
        of a DressUpModel in WotLK. Instead,
        we're undressing the whole model and
        dressing it up again without the slot. ]]
        mainFrame.dressingRoom:Undress()
        for _, slot in pairs(mainFrame.slots) do
            if slot.itemId ~= nil then
                mainFrame.dressingRoom:TryOn(slot.itemId)
            end
        end
    end
end

local function slot_SetItem(self, itemId)
    self.itemId = itemId
    ns.QueryItem(itemId, function(queriedItemId, success)
        if queriedItemId == self.itemId and success then
            local _, _, _, _, _, _, _, _, _, texture = GetItemInfo(queriedItemId)
            self.textures.empty:Hide()
            self.textures.item:SetTexture(texture)
            self.textures.item:Show()
            mainFrame.dressingRoom:TryOn(queriedItemId)
        end
    end)
end

--------- Slot building

do
    for slotName, texturePath in pairs(slotTextures) do
        local slot = CreateFrame("Button", "$parentSlot"..slotName, mainFrame, "ItemButtonTemplate")
        slot:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        slot:SetFrameLevel(mainFrame.dressingRoom:GetFrameLevel() + 1)
        slot:SetScript("OnClick", slot_OnClick)
        slot:SetScript("OnEnter", slot_OnEnter)
        slot:SetScript("OnLeave", slot_OnLeave)
        slot.slotName = slotName
        mainFrame.slots[slotName] = slot
        slot.textures = {}
        slot.textures.empty = slot:CreateTexture(nil, "BACKGROUND")
        slot.textures.empty:SetTexture(texturePath)
        slot.textures.empty:SetAllPoints()
        slot.textures.item = slot:CreateTexture(nil, "BACKGROUND")
        slot.textures.item:SetAllPoints()
        slot.textures.item:Hide()
        slot.Reset = slot_Reset
        slot.SetItem = slot_SetItem
        slot.RemoveItem = slot_RemoveItem
    end

    local slots = mainFrame.slots
    slots["Head"]:SetPoint("TOPLEFT", mainFrame.dressingRoom, "TOPLEFT", 16, -16)
    slots["Shoulder"]:SetPoint("TOP", slots["Head"], "BOTTOM", 0, -4)
    slots["Back"]:SetPoint("TOP", slots["Shoulder"], "BOTTOM", 0, -4)
    slots["Chest"]:SetPoint("TOP", slots["Back"], "BOTTOM", 0, -4)
    slots["Shirt"]:SetPoint("TOP", slots["Chest"], "BOTTOM", 0, -36)
    slots["Tabard"]:SetPoint("TOP", slots["Shirt"], "BOTTOM", 0, -4)
    slots["Wrist"]:SetPoint("TOP", slots["Tabard"], "BOTTOM", 0, -36)
    slots["Hands"]:SetPoint("TOPRIGHT", mainFrame.dressingRoom, "TOPRIGHT", -16, -16)
    slots["Waist"]:SetPoint("TOP", slots["Hands"], "BOTTOM", 0, -4)
    slots["Legs"]:SetPoint("TOP", slots["Waist"], "BOTTOM", 0, -4)
    slots["Feet"]:SetPoint("TOP", slots["Legs"], "BOTTOM", 0, -4)
    slots["Off-hand"]:SetPoint("BOTTOM", mainFrame.dressingRoom, "BOTTOM", 0, 16)
    slots["Main Hand"]:SetPoint("RIGHT", slots["Off-hand"], "LEFT", -4, 0)
    slots["Ranged"]:SetPoint("LEFT", slots["Off-hand"], "RIGHT", 4, 0)
end

------- Tricks and hooks with slots and provided appearances. -------


local function btnReset_Hook()
    mainFrame.dressingRoom:Undress()
    for _, slot in pairs(mainFrame.slots) do
        if slot.slotName == rangedSlot and ("DRUIDSHAMANPALADINDEATHKNIGHT"):find(classFileName) then
            slot:RemoveItem()
        else
            slot:Reset()
        end
    end
    if mainFrame.dressingRoom.shadowformEnabled then
        mainFrame.dressingRoom:EnableShadowform()
    end
end

local function btnUndress_Hook()
    for _, slot in pairs(mainFrame.slots) do
        slot.itemId = nil
        slot.textures.empty:Show()
        slot.textures.item:Hide()
    end
end

local function tryOnFromSlots(dressUpModel)
    for _, slot in pairs(mainFrame.slots) do
        if slot.itemId ~= nil then
            dressUpModel:TryOn(slot.itemId)
        end
    end
end

local function refreshDressingRoomFromSlots(unitToken)
    if unitToken ~= nil then
        mainFrame.dressingRoom:SetUnit(unitToken)
    end

    mainFrame.dressingRoom:Undress()
    tryOnFromSlots(mainFrame.dressingRoom)

    if mainFrame.dressingRoom.shadowformEnabled then
        mainFrame.dressingRoom:EnableShadowform()
    end
end

--[[
    Have to reTryOn selected appearances since
    the model's reset each time it's shown.
]]
--[[
    After half a year I don't remeber anymore
    why I do it, but showing/hiding a DressUpModel
    breaks the model's positioning.
]]
local function dressingRoom_OnShow(self)
    self:Reset()
    self:Undress()
    tryOnFromSlots(self)
    if self.shadowformEnabled then
        self:EnableShadowform()
    end
end

--[[
    Need to TryOn items in the slots if we changed
    displayed model.
]]
mainFrame.buttons.useTarget:HookScript("OnClick", function(slef)
    if mainFrame.dressingRoom.shadowformEnabled then
        mainFrame.dressingRoom:EnableShadowform()
    end
    mainFrame.dressingRoom:Undress()
    tryOnFromSlots(mainFrame.dressingRoom)
end)

-- At first time it's shown.
mainFrame.slots[defaultSlot]:SetScript("OnShow", function(self)
    self:SetScript("OnShow", nil)
    mainFrame.buttons.reset:HookScript("OnClick", btnReset_Hook)
    mainFrame.dressingRoom:HookScript("OnShow", dressingRoom_OnShow)
    dressingRoom_OnShow(mainFrame.dressingRoom)
    btnReset_Hook()
    mainFrame.buttons.undress:HookScript("OnClick", btnUndress_Hook)
    self:Click("LeftButton")
end)

---------------- SHADOWFORM ----------------

mainFrame.buttons.shadowform = CreateFrame("Button", "$parentShadowformButton", mainFrame, "ItemButtonTemplate")

do
    local enableTexture = "Interface\\Icons\\spell_shadow_shadowform"
    local disableTexture = "Interface\\Icons\\spell_nature_wispsplode"
    
    local btn = mainFrame.buttons.shadowform
    btn:SetSize(28, 28)
    _G[btn:GetName().."NormalTexture"]:SetAllPoints()
    _G[btn:GetName().."NormalTexture"]:SetTexCoord(0.1875, 0.796875, 0.1875, 0.796875)

    btn:SetPoint("RIGHT", mainFrame.dressingRoom, "BOTTOMRIGHT", -16, 54)
    btn:SetFrameLevel(mainFrame.dressingRoom:GetFrameLevel() + 1)

    local texture = btn:CreateTexture(nil, "BACKGROUND")
    texture:SetAllPoints()
    texture:SetTexture(enableTexture)

    btn:RegisterForClicks("LeftButtonUp")
    btn:SetScript("OnClick", function(self)
        PlaySound("gsTitleOptionOK")
        if not mainFrame.dressingRoom.shadowformEnabled then
            mainFrame.dressingRoom:EnableShadowform()
            texture:SetTexture(disableTexture)
            self:LockHighlight()
        else
            mainFrame.dressingRoom:DisableShadowform()
            texture:SetTexture(enableTexture)
            self:UnlockHighlight()
        end
    end)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:ClearLines()
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:AddLine("Shadowform")
        GameTooltip:AddLine("A poor simulation that relies on the model's light setup. Equipment with its own light source (like  \"Excavator's Brand\" tourch) gives wrong result. Emission textures that ignore light (like Draenei eyes) also ignore the simulation and are not shaded as they would be in the true shadowform.", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)

    btn:SetScript("OnLeave", function(self)
        GameTooltip:ClearLines()
        GameTooltip:Hide()
    end)
end

---------------- CHARACTER MENU BUTTON ----------------

local btnAppearanceBuddy = CreateFrame("Button", "$parent"..addon.."AppearanceBuddyButton", CharacterModelFrame, "UIPanelButtonTemplate2")
btnAppearanceBuddy:SetSize(80, 20)
btnAppearanceBuddy:SetPoint("BOTTOMRIGHT", -2, 25)
btnAppearanceBuddy:SetText("Appearance")
btnAppearanceBuddy:SetScript("OnClick", function(self)
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        mainFrame:Show() 
    end
end)

---------------- SETTINGS TAB ----------------


do  --------- Preview Setup
    local settingsTab = mainFrame.tabs.settings

    settingsTab.previewSetupMenu = CreateFrame("Frame", "$parentPreviewSetupDropDownMenu", settingsTab, "UIDropDownMenuTemplate")
    
    local menu = settingsTab.previewSetupMenu

    local function menu_OnClick(self, mode)
        GetSettings().previewSetup = mode
        UIDropDownMenu_SetText(menu, mode)
        previewSetupVersion = mode
        if mainFrame.selectedSlot ~= nil then
            mainFrame.selectedSlot:Click("LeftButton")
        end
    end

    UIDropDownMenu_Initialize(menu, function(frame)
        local previewSetup = GetSettings().previewSetup
        local info = UIDropDownMenu_CreateInfo()
        info.text, info.checked, info.arg1, info.func = "classic", previewSetup == "classic", "classic", menu_OnClick
        UIDropDownMenu_AddButton(info)
        info.text, info.checked, info.arg1, info.func = "modern", previewSetup == "modern", "modern", menu_OnClick
        UIDropDownMenu_AddButton(info)
    end)

    local label = menu:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("TOPLEFT", settingsTab, "TOPLEFT", 16, -24)
    label:SetText("Used models:")

    local tipFrame = CreateFrame("Frame", addon.."PreviewSetupDropDownMenuTip", settingsTab)
    tipFrame:SetPoint("LEFT", label, "LEFT")
    tipFrame:SetPoint("RIGHT", menu:GetChildren(), "LEFT")
    tipFrame:SetHeight(menu:GetChildren():GetHeight())
    tipFrame:EnableMouse(true)
    tipFrame:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Used models")
        GameTooltip:AddLine("There's a funmade modification for WotLK client that brings modern high quality character models from \"Warlords of Draenor\" expansion. Unfortunately, preview for the modern models has different setup. If your game client's using the modern models, choose \"modern\" in this popup menu and \"classic\" otherwise.", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    tipFrame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    
    menu:SetPoint("TOPLEFT", label:GetWidth() + 10, -16)

    settingsTab.SetPreviewSetup = function(self, mode)
        menu_OnClick(nil, mode)
    end
end


do  --------- Character background
    local settingsTab = mainFrame.tabs.settings
    local textures = mainFrame.dressingRoom.backgroundTextures

    local colorButtonBackground = CreateFrame("Frame", "$parentBorderDressingRoomBackgroundColorPicker", settingsTab)
    colorButtonBackground:SetSize(24, 24)
    colorButtonBackground:SetBackdrop({bgFile = "Interface\\ChatFrame\\ChatFrameBackground"})
    colorButtonBackground:SetBackdropColor(0.15, 0.15, 0.15, 1)

    local colorButton = CreateFrame("Button", "$parentButton", colorButtonBackground)
    colorButton:SetPoint("TOPLEFT", 2, -2)
    colorButton:SetPoint("BOTTOMRIGHT", -2, 2)
    colorButton:RegisterForClicks("LeftButtonDown")
    
    colorButton:SetBackdrop({bgFile = "Interface\\ChatFrame\\ChatFrameBackground"})
    colorButton:SetBackdropColor(unpack(defaultSettings.dressingRoomBackgroundColor))

    local label = colorButtonBackground:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("TOPLEFT", settingsTab, "TOPLEFT", 16, -80)
    label:SetText("Character background:")

    colorButtonBackground:SetPoint("TOPRIGHT", label, "BOTTOMRIGHT", 0, -4)

    local function colorPicker_OnAccept()
        local r, g, b = ColorPickerFrame:GetColorRGB() 
        textures.color:SetTexture(r, g, b)
        colorButton:SetBackdropColor(r, g, b)
        GetSettings().dressingRoomBackgroundColor = {r, g, b}
    end

    local function colorPicker_OnCancel(previousValues)
        local settings = GetSettings()
        textures.color:SetTexture(unpack(previousValues))
        colorButton:SetBackdropColor(unpack(previousValues))
        GetSettings().dressingRoomBackgroundColor = {unpack(previousValues)}
    end

    colorButton:SetScript("OnClick", function(self)
        local r, g, b = unpack(GetSettings().dressingRoomBackgroundColor)
        ColorPickerFrame.previousValues = {r, g, b}
        ColorPickerFrame:SetColorRGB(r, g, b)
        ColorPickerFrame.func = colorPicker_OnAccept
        ColorPickerFrame.cancelFunc = colorPicker_OnCancel
        ColorPickerFrame:Hide()
        ColorPickerFrame:Show()
    end)

    local btnReset = CreateFrame("Button", "$parentResetButton", colorButtonBackground, "UIPanelButtonTemplate2")
    btnReset:SetPoint("TOPLEFT", label, "BOTTOMLEFT", 0, -6)
    btnReset:SetText("Reset Color")
    btnReset:SetWidth(100)
    btnReset:SetScript("OnClick", function(self)
        local r, g, b = unpack(defaultSettings.dressingRoomBackgroundColor)
        GetSettings().dressingRoomBackgroundColor = {r, g, b}
        textures.color:SetTexture(r, g, b)
        colorButton:SetBackdropColor(r, g, b)
        PlaySound("gsTitleOptionOK")
    end)

    settingsTab.backgroundMenu = CreateFrame("Frame", "$parentDropDownMenu", colorButtonBackground, "UIDropDownMenuTemplate")
    
    local menu = settingsTab.backgroundMenu
    local function getText(background)
        return  (background == "deathknight" and "Death Knight")
                or (background == "nightelf" and "Night Elf")
                or (background == "bloodelf" and "Blood Elf")
                or (background == "scourge" and "Forsaken")
                or background:gsub("^%l", string.upper)
    end

    local function menu_OnClick(self, background)
        GetSettings().dressingRoomBackgroundTexture[GetRealmName()][GetUnitName("player")] = background
        for _, tex in pairs(textures) do
            tex:Hide()
        end
        textures[background]:Show()
        UIDropDownMenu_SetText(menu, getText(background))
    end

    UIDropDownMenu_Initialize(menu, function()
        local currBackground = GetSettings().dressingRoomBackgroundTexture[GetRealmName()][GetUnitName("player")]:lower()
        local info = UIDropDownMenu_CreateInfo()
        for background in ("color,human,dwarf,nightelf,gnome,draenei,orc,scourge,tauren,troll,bloodelf,deathknight"):gmatch("%w+") do
            info.text = getText(background)
            info.checked = currBackground == background
            info.arg1 = background
            info.func = menu_OnClick
            UIDropDownMenu_AddButton(info)
        end
    end)

    settingsTab.SetCharacterBackground = function(self, background, r, g, b)
        menu_OnClick(nil, background:lower())
        colorButton:SetBackdropColor(r, g, b)
        textures.color:SetTexture(r, g, b)
    end
    
    menu:SetPoint("LEFT", label, "RIGHT")
    UIDropDownMenu_SetWidth(menu, 100)
end


do  --------- Show/hide "Appearance Buddy" button
    local settingsTab = mainFrame.tabs.settings
    settingsTab.showAppearanceBuddyButtonCheckBox = CreateFrame("CheckButton", "$parentShowAppearanceBuddyButtonCheckBox", settingsTab, "ChatConfigCheckButtonTemplate")

    local checkbox = settingsTab.showAppearanceBuddyButtonCheckBox
    checkbox:SetPoint("TOPLEFT", settingsTab, "TOPLEFT", 15, -150)
    checkbox:SetScript("OnClick", function(self)
        if self:GetChecked() then
            btnAppearanceBuddy:Show()
            GetSettings().showAppearanceBuddyButton = true
        else
            btnAppearanceBuddy:Hide()
            GetSettings().showAppearanceBuddyButton = false
        end
    end)
    checkbox:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Show \"Appearance\" button")
        GameTooltip:AddLine("Show or hide \"Appearance\" button in the character window.", 1, 1, 1, 1, true)
        GameTooltip:AddLine("The addon can be still accessed via \"/appearancebuddy\" chat command.", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    checkbox:HookScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    local label = checkbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetText("Show \"Appearance\" button")
    label:SetPoint("LEFT", checkbox, "RIGHT", 4, 2)
end


do  --------- Show shortcuts in tooltips
    local settingsTab = mainFrame.tabs.settings
    settingsTab.showShortcutsInTooltipCheckBox = CreateFrame("CheckButton", "$parentShowShortcutsInTooltipCheckBox", settingsTab, "ChatConfigCheckButtonTemplate")
    
    local checkbox = settingsTab.showShortcutsInTooltipCheckBox
    checkbox:SetPoint("TOP", settingsTab.showAppearanceBuddyButtonCheckBox, "BOTTOM", 0, -10)
    checkbox:SetScript("OnClick", function(self)
        GetSettings().showShortcutsInTooltip = self:GetChecked() ~= nil
    end)
    local label = checkbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetText("Show shortcuts in tooltip")
    label:SetPoint("LEFT", checkbox, "RIGHT", 4, 2)
end


do  --------- Ignore UI scaling
    local settingsTab = mainFrame.tabs.settings
    settingsTab.ignoreUIScalingCheckBox = CreateFrame("CheckButton", "$parentIgnoreUIScalingCheckBox", settingsTab, "ChatConfigCheckButtonTemplate")
    
    local checkbox = settingsTab.ignoreUIScalingCheckBox
    checkbox:SetPoint("TOP", settingsTab.showShortcutsInTooltipCheckBox, "BOTTOM", 0, -30)
    checkbox:SetScript("OnClick", function(self)
        GetSettings().ignoreUIScaling = self:GetChecked() ~= nil
        if self:GetChecked() then
            mainFrame:SetParent(nil)
            mainFrame:SetScale(0.9)
        else
            mainFrame:SetParent(UIParent)
            mainFrame:SetScale(1)
        end
        if mainFrame:IsVisible() then
            -- only to update the main dressing room
            mainFrame:Hide()
            mainFrame:Show()
        end
    end)
    local origingSetChecked = checkbox.SetChecked
    checkbox.SetChecked = function(self, enable)
        origingSetChecked(self, enable)
        checkbox:GetScript("OnClick")(self)
    end
    checkbox:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Ignore UI scaling")
        GameTooltip:AddLine("The game's 3D rendering can break correct display of previews with low UI scaling values. Enable this to bypass UI scaling.", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    checkbox:HookScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    local label = checkbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetText("Ignore UI scaling")
    label:SetPoint("LEFT", checkbox, "RIGHT", 4, 2)
end


do  --------- Lock window
    local settingsTab = mainFrame.tabs.settings
    settingsTab.windowLockedCheckBox = CreateFrame("CheckButton", "$parentWindowLockedCheckBox", settingsTab, "ChatConfigCheckButtonTemplate")

    local checkbox = settingsTab.windowLockedCheckBox
    checkbox:SetPoint("TOP", settingsTab.ignoreUIScalingCheckBox, "BOTTOM", 0, -10)
    checkbox:SetScript("OnClick", function(self)
        GetSettings().windowLocked = self:GetChecked() ~= nil
        if mainFrame.UpdateWindowLockState then
            mainFrame.UpdateWindowLockState()
        end
    end)
    checkbox:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Lock window")
        GameTooltip:AddLine("Prevent Appearance Buddy from being moved.", 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    checkbox:HookScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    local label = checkbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetText("Lock window")
    label:SetPoint("LEFT", checkbox, "RIGHT", 4, 2)
end



do  --------- Apply settings on addon loaded
    local settingsTab = mainFrame.tabs.settings

    local function applySettings(settings)
        -- Dressing room background: always auto-match to the player's race.
        -- Death Knights get the Death Knight background regardless of race.
        local autoBackground = classFileName == "DEATHKNIGHT" and "deathknight" or raceFileName:lower()
        settingsTab:SetCharacterBackground(autoBackground, unpack(settings.dressingRoomBackgroundColor))
        -- Preview setup popup menu
        settingsTab:SetPreviewSetup(settings.previewSetup)
        -- Show/hide "Appearance Buddy" button
        settingsTab.showAppearanceBuddyButtonCheckBox:SetChecked(settings.showAppearanceBuddyButton)
        if settings.showAppearanceBuddyButton then
            btnAppearanceBuddy:Show()
        else
            btnAppearanceBuddy:Hide()
        end
        -- Show shortcuts in tooltip
        settingsTab.showShortcutsInTooltipCheckBox:SetChecked(settings.showShortcutsInTooltip)
        -- Ignore UI scaling
        settingsTab.ignoreUIScalingCheckBox:SetChecked(settings.ignoreUIScaling)
        -- Lock window
        settingsTab.windowLockedCheckBox:SetChecked(settings.windowLocked)
        if mainFrame.UpdateWindowLockState then
            mainFrame.UpdateWindowLockState()
        end
    end

    settingsTab:RegisterEvent("ADDON_LOADED")
    settingsTab:SetScript("OnEvent", function(self, event, addonName)
        if addonName == addon then
            if event == "ADDON_LOADED" then
                applySettings(GetSettings())
            end
        end
    end)
end

---------------- CHAT COMMANDS ----------------

ns.mainFrame = mainFrame
ns.GetSettings = GetSettings
ns.RefreshManagedScrollFrame = RefreshManagedScrollFrame
ns.GetPreviewSetupVersion = function()
    return previewSetupVersion
end
ns.RefreshDressingRoomFromSlots = refreshDressingRoomFromSlots
ns.SetAppearanceBuddyPreviewControlsVisible = function(visible)
    for _, slot in pairs(mainFrame.slots) do
        if visible then
            slot:Show()
        else
            slot:Hide()
        end
    end

    for _, name in ipairs({"send", "reset", "undress", "useTarget", "shadowform"}) do
        local button = mainFrame.buttons[name]
        if button then
            if visible then
                button:Show()
            else
                button:Hide()
            end
        end
    end
end

SLASH_APPEARANCEBUDDY1 = "/appearancebuddy"
SLASH_APPEARANCEBUDDY2 = "/ab"

-- Scan results popup (created once, reused)
local function getScanPopup()
    if _G["AppearanceBuddyScanPopup"] then
        return _G["AppearanceBuddyScanPopup"]
    end
    local p = CreateFrame("Frame", "AppearanceBuddyScanPopup", UIParent)
    p:SetSize(540, 360)
    p:SetPoint("CENTER")
    p:SetMovable(true)
    p:EnableMouse(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", p.StartMoving)
    p:SetScript("OnDragStop", p.StopMovingOrSizing)
    p:SetBackdrop({
        bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = {left = 3, right = 3, top = 3, bottom = 3}
    })
    p:SetBackdropColor(0.08, 0.08, 0.08, 0.97)
    p:SetBackdropBorderColor(0.55, 0.55, 0.55)

    local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -9)
    title:SetText("|cff00ff00AppearanceBuddy Frame Scan|r  (Ctrl+A then Ctrl+C to copy)")

    local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() p:Hide() end)

    local sf = CreateFrame("ScrollFrame", "AppearanceBuddyScanScroll", p, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 8, -26)
    sf:SetPoint("BOTTOMRIGHT", -26, 8)

    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true)
    eb:SetMaxLetters(0)
    eb:EnableMouse(true)
    eb:SetAutoFocus(false)
    eb:SetFontObject(GameFontHighlightSmall)
    eb:SetWidth(490)
    eb:SetScript("OnEscapePressed", function() p:Hide() end)
    sf:SetScrollChild(eb)
    p.editBox = eb

    return p
end

SlashCmdList["APPEARANCEBUDDY"] = function(msg)
    if msg == "" then
        if mainFrame:IsShown() then mainFrame:Hide() else mainFrame:Show() end
    elseif msg == "debug" then
        if mainFrame.dressingRoom:IsDebugInfoShown() then mainFrame.dressingRoom:HideDebugInfo() else mainFrame.dressingRoom:ShowDebugInfo() end
    elseif msg == "scan" then
        local mfLeft, mfBottom, mfWidth, mfHeight = mainFrame:GetLeft(), mainFrame:GetBottom(), mainFrame:GetWidth(), mainFrame:GetHeight()
        if not mfLeft then
            print("|cffff4444AppearanceBuddy scan:|r Open the window first.")
            return
        end
        local mfRight  = mfLeft   + mfWidth
        local mfTop    = mfBottom + mfHeight
        -- Search zone: mainFrame area expanded by 600px on all sides
        local expand = 600
        local zL, zR = mfLeft - expand, mfRight  + expand
        local zB, zT = mfBottom - expand, mfTop + expand

        local lines = {}
        lines[#lines+1] = string.format("mainFrame: (%.0f,%.0f)-(%.0f,%.0f)  size %.0fx%.0f",
            mfLeft, mfBottom, mfRight, mfTop, mfWidth, mfHeight)
        lines[#lines+1] = "Visible frames within 300px of window:"
        lines[#lines+1] = ""

        local count = 0
        local frame = EnumerateFrames()
        while frame do
            if frame:IsVisible() and frame ~= mainFrame then
                local fl, fb, fw, fh = frame:GetLeft(), frame:GetBottom(), frame:GetWidth(), frame:GetHeight()
                if fl and fb and fw and fh and fw > 0 and fh > 0 then
                    local fr = fl + fw
                    local ft = fb + fh
                    -- Include only frames that overlap the search zone
                    if fr > zL and fl < zR and ft > zB and fb < zT then
                        local name = frame:GetName() or "(no name)"
                        local otype = frame:GetObjectType()
                        local outsideTag = ""
                        if fr <= mfLeft or fl >= mfRight or ft <= mfBottom or fb >= mfTop then
                            outsideTag = " *** OUTSIDE ***"
                        end
                        lines[#lines+1] = string.format("[%s] %s  (%.0f,%.0f)-(%.0f,%.0f)%s",
                            otype, name, fl, fb, fr, ft, outsideTag)
                        count = count + 1
                    end
                end
            end
            frame = EnumerateFrames(frame)
        end

        if count == 0 then
            lines[#lines+1] = "(none found)"
        end

        local popup = getScanPopup()
        local text = table.concat(lines, "\n")
        popup.editBox:SetText(text)
        popup.editBox:SetCursorPosition(0)
        popup:Show()
        popup:Raise()
        print("|cff00ff00AppearanceBuddy:|r Scan complete — " .. count .. " frame(s). See popup window.")
    end
end
